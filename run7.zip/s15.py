from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont

# [1] 천단위 콤마 및 소수점 처리 아이템
class S15ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if not val or val == "" or val == "0": return "0"
            try:
                clean_val = str(val).replace(',', '')
                num = float(clean_val)
                # 28, 29행(생산성 지표)은 소수점 2자리, 나머지는 정수 콤마
                if self.row() in [28, 29]:
                    return format(num, ",.2f")
                return format(int(num), ",")
            except: return val
        return super().data(role)

# [2] 실시간 입력 및 보호 델리게이트
class S15RightAlignedDelegate(QStyledItemDelegate):
    def createEditor(self, parent, option, index):
        # 보호할 행들 (자동 계산되는 소계/합계 행만)
        # 1(인건비소계), 5(합계), 6(금융소계), 9(합계), 10(임차료소계), 13(합계), 
        # 14(세금소계), 17(합계), 18(상각소계), 23(합계), 25(부가가치), 28, 29(지표)
        protected_rows = [1, 5, 6, 9, 10, 13, 14, 17, 18, 23, 25, 28, 29]
        if index.column() == 0 or index.row() in protected_rows:
            return None
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        return editor

    def setModelData(self, editor, model, index):
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)

class Sheet15Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_sky_blue = QColor(220, 235, 245) # 숫자/합계 배경색
        self.header_gray = QColor(240, 240, 240)    # 타이틀 바 배경색
        self.very_light_gray = QColor(252, 252, 252)
        self.initUI()



    def initUI(self):
        layout = QVBoxLayout(self)
        title = QLabel("hwp 26페이지: (4) 노동생산성, 자본생산성 지표의 점수계산을 위한 Template")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)

        self.table = QTableWidget(30, 4) # 행 개수 최적화 (0~29)
        self.table.setHorizontalHeaderLabels(["구분", "2025", "2024", "2023"])
        
        # 테이블 스타일 (사용자 지침 반영)
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section { 
                background-color: #f4f4f4; font-weight: bold; border: 1px solid #d0d0d0;
            }
        """)

        self.table.setColumnWidth(0, 400)
        for i in range(1, 4): self.table.setColumnWidth(i, 130)

        self.delegate = S15RightAlignedDelegate(self.table)
        for i in range(1, 4): self.table.setItemDelegateForColumn(i, self.delegate)

        self.setup_content()
        self.table.itemChanged.connect(self.calculate_totals)
        layout.addWidget(self.table)

    def setup_content(self):
        self.table.blockSignals(True)
        rows = [
            "1. 손익계산서상의 세전이익 (A) <주1>", "2. 인건비", 
            "  a. 판관비로 처리한 부분 <주2>", "  b. 영업외비용으로 처리한 부분 <주3>", 
            "  c. 제조원가로 처리한 부분 <주4>", "▶ 인건비 합계: (B)=a+b+c",
            "3. 순금융비용 <주5>", "  d. 손익계산서상 이자비용", "  e. 손익계산서상 이자수익", "▶ 순금융비용 합계: (C)=d-e",
            "4. 임차료", "  f. 손익계산서상 임차료", "  g. 제조원가명세서상 임차료", "▶ 임차료 합계: (D)=f+g",
            "5. 세금과공과", "  h. 손익계산서상 세금과공과", "  i. 제조원가명세서상 세금과공과", "▶ 세금과 공과 합계: (E)=h+i",
            "6. 감가상각비", "  j. 손익계산서상의 유형자산 감가상각비", "  k. 손익계산서상의 무형자산 감가상각비",
            "  l. 제조원가명세서상의 유형자산 감가상각비", "  m. 제조원가명세서상의 무형자산 감가상각비", "▶ 감가상각비 합계: (F)=j+k+l+m",
            "7. 소송관련 충당금 전입액 (G) <주6>", "■ 부가가치: (H)=(A)+(B)+(C)+(D)+(E)+(F)+(G)",
            "평균 총인원 (I) <주7>", "평균 총자산 (J)", "◎ 노동생산성 지표 = (H)/(I)", "◎ 자본생산성 지표 = (H)/(J)"
        ]

        for r, text in enumerate(rows):
            # 1. 스타일을 위한 판단: 1~7번 전체 제목 및 특수기호 행은 굵게
            is_bold_title = any(text.strip().startswith(f"{i}.") for i in range(1, 8)) or \
                            any(m in text for m in ["▶", "■", "◎"])

            # 2. 입력을 막기 위한 판단: 2~6번 대분류 및 특수기호 행은 자동계산(파란색)
            is_auto_calc = any(text.strip().startswith(f"{i}.") for i in range(2, 7)) or \
                           any(m in text for m in ["▶", "■", "◎"])

            # --- 0열 (구분/제목 열) 설정 ---
            item_a = QTableWidgetItem(text)
            item_a.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            
            if is_bold_title:
                item_a.setBackground(self.header_gray) # 제목 행 배경(회색)
                font = item_a.font()
                font.setBold(True)                     # 여기서 1번, 7번도 굵어집니다
                item_a.setFont(font)
            else:
                item_a.setBackground(self.very_light_gray)
            self.table.setItem(r, 0, item_a)

            # --- 1~3열 (데이터 열) 설정 ---
            for c in range(1, 4):
                item = S15ThousandSeparatorItem("0")
                item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                
                if is_auto_calc:
                    # 자동계산 행: 파란색 배경 + 수정 불가
                    item.setBackground(self.base_sky_blue)
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                else:
                    # 1번, 7번 및 일반 항목: 흰색 배경 + 입력 가능
                    item.setBackground(QColor(255, 255, 255))
                self.table.setItem(r, c, item)
        self.table.blockSignals(False)





        

    def calculate_totals(self, item):
        col = item.column()
        if col == 0: return
        self.table.blockSignals(True)
        try:
            def gv(r):
                it = self.table.item(r, col)
                return float(it.text().replace(',', '')) if it and it.text() else 0.0
            def sv(r, val):
                self.table.item(r, col).setText(str(int(val)))

            vA = gv(0) # 1. 세전이익
            vB = gv(2)+gv(3)+gv(4); sv(1, vB); sv(5, vB) # 2. 인건비
            vC = gv(7)-gv(8); sv(6, vC); sv(9, vC)      # 3. 순금융
            vD = gv(11)+gv(12); sv(10, vD); sv(13, vD)   # 4. 임차료
            vE = gv(15)+gv(16); sv(14, vE); sv(17, vE)   # 5. 세금
            vF = gv(19)+gv(20)+gv(21)+gv(22); sv(18, vF); sv(23, vF) # 6. 상각
            vG = gv(24) # 7. 소송충당금

            # 부가가치 H
            vH = vA + vB + vC + vD + vE + vF + vG
            sv(25, vH)

            # 지표
            vI, vJ = gv(26), gv(27)
            if vI != 0: self.table.item(28, col).setText(str(vH / vI))
            if vJ != 0: self.table.item(29, col).setText(str(vH / vJ))
        except: pass
        finally: self.table.blockSignals(False)

























# --- 우클릭 메뉴 ---
    def show_context_menu(self, pos):
        menu = QMenu()
        copy_action = menu.addAction("복사")
        paste_action = menu.addAction("붙여넣기")
        
        action = menu.exec_(self.table.viewport().mapToGlobal(pos))
        if action == copy_action:
            self.copy_selection()
        elif action == paste_action:
            self.paste_selection()

    # --- [개선] 지능형 복사 로직 (일반 값은 값으로, 소계는 수식으로) ---
    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        
        min_r, max_r = min(r.topRow() for r in selection), max(r.bottomRow() for r in selection)
        min_c, max_c = min(r.leftColumn() for r in selection), max(r.rightColumn() for r in selection)
        
        lines = []
        
        # 헤더 복사
        if min_r == 0:
            header_labels = [self.table.horizontalHeaderItem(c).text() for c in range(min_c, max_c + 1)]
            lines.append("\t".join(header_labels))

        for r in range(min_r, max_r + 1):
            row_data = []
            for c in range(min_c, max_c + 1):
                item = self.table.item(r, c)
                text = item.text() if item else ""
                
                if c >= 1:
                    col_L = chr(ord('A') + c) 
                    # [교정] PyQt index r=5 (인건비 합계) -> 엑셀에서는 7행입니다. (제목 1행 + 1~6행 데이터)
                    # 따라서 엑셀 행 번호 ex_r = r + 2 가 맞습니다.
                    ex_r = r + 2 
                    
                    formulas = {
                        5:  f"={col_L}{ex_r-3}+{col_L}{ex_r-2}+{col_L}{ex_r-1}", # (B)인건비 합계: 4,5,6행 더하기
                        9:  f"={col_L}{ex_r-2}-{col_L}{ex_r-1}",               # (C)순금융비용: 8-9행
                        13: f"={col_L}{ex_r-2}+{col_L}{ex_r-1}",               # (D)임차료: 12+13행
                        17: f"={col_L}{ex_r-2}+{col_L}{ex_r-1}",               # (E)세금과공과: 16+17행
                        23: f"={col_L}{ex_r-4}+{col_L}{ex_r-3}+{col_L}{ex_r-2}+{col_L}{ex_r-1}", # (F)감가상각비
                        # (H)부가가치: (A:2행)+(B:7행)+(C:11행)+(D:15행)+(E:19행)+(F:25행)+(G:26행)
                        25: f"={col_L}2+{col_L}7+{col_L}11+{col_L}15+{col_L}19+{col_L}25+{col_L}26", 
                        28: f"=IF({col_L}{ex_r-1}=0,0,{col_L}{ex_r-2}/{col_L}{ex_r-1})", # 노동생산성: H/I
                        29: f"=IF({col_L}{ex_r-1}=0,0,{col_L}{ex_r-3}/{col_L}{ex_r-1})"  # 자본생산성: H/J
                    }
                    val = formulas.get(r, text.replace(',', ''))
                else:
                    val = text
                row_data.append(val)
            lines.append("\t".join(row_data))
        QApplication.clipboard().setText("\n".join(lines))
        

    # --- [유지] 붙여넣기 로직 ---
    def paste_selection(self):
        clipboard = QApplication.clipboard().text()
        if not clipboard: return
        
        rows = clipboard.split('\n')
        current_item = self.table.currentItem()
        if not current_item: return
        
        start_row = current_item.row()
        start_col = current_item.column()
        
        self.table.blockSignals(True)
        for i, row_text in enumerate(rows):
            if not row_text.strip(): continue
            cols = row_text.split('\t')
            for j, col_text in enumerate(cols):
                r, c = start_row + i, start_col + j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    # 수정 불가능한 셀(합계 행 등)은 건너뜀
                    if c >= 1 and r not in [5, 8, 11, 14, 19, 21, 28, 29]:
                        clean_text = col_text.strip().replace(',', '')
                        item = self.table.item(r, c)
                        if item:
                            item.setData(Qt.EditRole, clean_text)
        self.table.blockSignals(False)
        # 데이터 변경 후 합계 재계산 트리거
        self.calculate_totals(self.table.item(start_row, start_col))

    # 우클릭 메뉴 및 복사/붙여넣기 로직 (중복 제거)
    def keyPressEvent(self, event):
        if event.modifiers() == Qt.ControlModifier:
            if event.key() == Qt.Key_C: self.copy_selection()
            elif event.key() == Qt.Key_V: self.paste_selection()
        else: super().keyPressEvent(event)




    def handle_help_popup(self, item):
        if item.column() != 0: return
        helps = {
            0: "<b><주1></b> 세전이익에 전기오류수정손익이 포함된 경우 그 원인에 따라 제외 여부를 판단함...",
            2: "<b><주2></b> 인건비 집계를 위한 template상의 (가)에 기입된 금액을 옮겨 적음. (hwp 7페이지)",
            3: "<b><주3></b> 인건비 집계를 위한 template상의 (나)에 기입된 금액을 옮겨 적음. (hwp 7페이지)",
            4: "<b><주4></b> 인건비 집계를 위한 template상의 (다)에 기입된 금액을 옮겨 적음. (hwp 7페이지)",
            6: "<b><주5></b> 순금융비용이 음수인 경우에는 음수 금액 그 자체를 그대로 기재함.",
            24: "<b><주6></b> 유예한 소송 관련 충당금 전입액을 기입하며, 확정 판결시 차감함.",
            26: "<b><주7></b> 조정 후 평균총인원 산출 방법 참조 (hwp 내용)"
        }
        row = item.row()
        if row in helps:
            QMessageBox.information(self, "항목 상세 설명", f"<b>[{item.text()}]</b><br><br>{helps[row]}")






