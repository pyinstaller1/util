from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QKeySequence

# [1] S11 전용 우측 정렬 델리게이트
class S11RightAlignedDelegate(QStyledItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        return editor
    def setModelData(self, editor, model, index):
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)

# [2] S11 전용 천단위 콤마 아이템
class S11ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if val is None or str(val).strip() == "": return ""
            try:
                clean_val = str(val).replace(',', '')
                num = float(clean_val)
                if num == int(num): return format(int(num), ",")
                else: return format(num, ",.2f")
            except: return val
        return super().data(role)

class Sheet11Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_sky_blue = QColor(220, 235, 245)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        title = QLabel("hwp 23페이지: 다. 미승진자 평균인원")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)        

        self.table = QTableWidget(18, 15)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)

        # [수정] S7과 동일한 얇은 실선 스타일로 원복 (두꺼운 선 제거)
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section:horizontal {
                background-color: #f4f4f4; padding: 2px; 
                border: 0px; border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: bold;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; padding-left: 5px; padding-right: 5px;
                border: 0px; border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
            }
        """)

        headers = ["구분", "직급"] + [f"{i}월" for i in range(1, 13)] + ["평균인원"]
        self.table.setHorizontalHeaderLabels(headers)
        self.table.verticalHeader().setFixedWidth(25)
        self.table.verticalHeader().setDefaultSectionSize(26)

        self.delegate = S11RightAlignedDelegate(self.table)
        for i in range(2, 15):
            self.table.setItemDelegateForColumn(i, self.delegate)

        self.setup_content()
        
        self.table.setColumnWidth(0, 50); self.table.setColumnWidth(1, 60)
        for i in range(2, 14): self.table.setColumnWidth(i, 50)
        self.table.setColumnWidth(14, 70)

        self.table.itemChanged.connect(self.calculate_s11)
        layout.addWidget(self.table)

    def setup_content(self):
        self.table.blockSignals(True)
        # 1. 6직급 포함 리스트 (1~6직급, 별도직군, 계)
        ranks = ["1직급", "2직급", "3직급", "4직급", "5직급", "6직급", "... ...", "별도직군", "계"]
        
        full_headers = ["구분", "직급"] + [f"{i}월" for i in range(1, 13)] + ["평균인원"]
        
        # 전체 행 수 설정 (전년도9 + 구분선1 + 제목1 + 당년도9 + 구분선1 + 주석1 = 22)
        self.table.setRowCount(22)

        for r in range(22):
            for c in range(15):
                # 특수 행 (9:구분선, 10:중간제목, 20:구분선, 21:주석)
                if r in [9, 20]: 
                    item = QTableWidgetItem("")
                    item.setFlags(Qt.NoItemFlags); item.setBackground(Qt.white)
                elif r == 10: 
                    item = QTableWidgetItem(full_headers[c])
                    item.setTextAlignment(Qt.AlignCenter)
                    item.setBackground(QColor(244, 244, 244))
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    f = item.font(); f.setBold(True); item.setFont(f)
                elif r == 21:
                    note = ("hwp 23페이지: 다. 미승진자 평균인원\n\n"
                            " * 각 직급별 미승진자 인원은 ‘나. 별도직군 승진 가능 인원 내 미승진자 인원 계산’의 “미승진자” 인원을 기입함.\n"
                            " * 각 직급별 평균인원은 1월부터 12월까지의 인원 총계를 12로 나누어서 구하되 소수점 이하 둘째 자리에서 반올림함.")
                    item = QTableWidgetItem(note)
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    item.setTextAlignment(Qt.AlignLeft | Qt.AlignTop)
                else:
                    item = S11ThousandSeparatorItem("0")
                    item.setTextAlignment(Qt.AlignCenter if c < 2 else Qt.AlignRight | Qt.AlignVCenter)
                    
                    # 강조색 설정 (계 행, 평균인원 열, 직급 열)
                    if c == 1 or r == 8 or r == 19 or c == 14:
                        item.setBackground(self.base_sky_blue)
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        if r in [8, 19] or c == 14:
                            f = item.font(); f.setBold(True); item.setFont(f)
                    
                    # 구분 열 (0열)
                    if c == 0:
                        item.setBackground(QColor(245, 245, 245))
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        if r == 0: item.setText("전년도")
                        elif r == 11: item.setText("당년도")

                    # 직급 명칭 (1열)
                    if c == 1:
                        if 0 <= r <= 8: item.setText(ranks[r])
                        elif 11 <= r <= 19: item.setText(ranks[r-11])

                self.table.setItem(r, c, item)

        # 병합 및 높이 조절
        self.table.setSpan(0, 0, 9, 1); self.table.setSpan(11, 0, 9, 1); self.table.setSpan(21, 0, 1, 15)
        self.table.setRowHeight(9, 10); self.table.setRowHeight(20, 10); self.table.setRowHeight(21, 150)
        self.table.blockSignals(False)

    def calculate_s11(self, item):
        row, col = item.row(), item.column()
        if col < 2 or col == 14 or row in [8, 9, 10, 19, 20, 21]: return 
        
        self.table.blockSignals(True)
        try:
            # 6직급 포함 데이터 행 (0~7, 11~18)
            if 0 <= row <= 7: data_rows, sum_row = list(range(8)), 8
            elif 11 <= row <= 18: data_rows, sum_row = list(range(11, 19)), 19
            else: return

            # 1. 가로 평균 (1~12월 / 12)
            row_sum = sum(float(self.table.item(row, c).text().replace(',', '') or 0) for c in range(2, 14))
            self.table.item(row, 14).setText(str(round(row_sum / 12, 2)))

            # 2. 세로 합계 (각 월별 인원)
            col_sum = sum(float(self.table.item(r, col).text().replace(',', '') or 0) for r in data_rows)
            self.table.item(sum_row, col).setText(str(int(col_sum)))

            # 3. 평균인원 열의 합계
            total_avg = sum(float(self.table.item(r, 14).text().replace(',', '') or 0) for r in data_rows)
            self.table.item(sum_row, 14).setText(str(round(total_avg, 2)))
        except: pass
        finally: self.table.blockSignals(False)

    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        
        # 선택된 영역의 최소/최대 행/열 계산
        min_r, max_r = min(r.topRow() for r in selection), max(r.bottomRow() for r in selection)
        min_c, max_c = min(r.leftColumn() for r in selection), max(r.rightColumn() for r in selection)
        
        lines = []

        # [1] 제목줄 복사 (0행이 선택 범위에 포함되거나, 헤더를 명시적으로 복사하고 싶을 때)
        # 엑셀처럼 선택 영역 맨 위에 제목을 붙여줍니다.
        if min_r == 0:
            h_row = []
            for c in range(min_c, max_c + 1):
                h_item = self.table.horizontalHeaderItem(c)
                h_row.append(h_item.text().replace('\n', ' ') if h_item else "")
            lines.append("\t".join(h_row))

        for r in range(min_r, max_r + 1):
            # [2] 중간 제목줄(10행) 또는 구분선(9, 20행) 처리
            if r in [9, 10, 20]:
                row_data = []
                for c in range(min_c, max_c + 1):
                    it = self.table.item(r, c)
                    row_data.append(it.text().replace('\n', ' ') if it else "")
                lines.append("\t".join(row_data))
                continue

            # [3] 주석 행(21행) 처리 - 반복 복사 방지
            if r == 21:
                it = self.table.item(r, 0) # 주석은 0번 열에만 있음
                val = it.text().strip() if it else ""
                # 주석은 한 줄만 추가 (선택된 열 개수만큼 탭만 붙여서 정렬 유지)
                lines.append(val + "\t" * (max_c - min_c))
                continue
                
            # [4] 일반 데이터 행 처리
            row_data = []
            ex_r = r + 2 # 엑셀 행 번호 보정

            for c in range(min_c, max_c + 1):
                col_let = chr(65 + c)
                # 평균인원 열 수식
                if c == 14 and r not in [8, 19]:
                    row_data.append(f"=ROUND(AVERAGE(C{ex_r}:N{ex_r}), 2)")
                # 전년도 합계 수식
                elif r == 8 and c >= 2:
                    row_data.append(f"=SUM({col_let}2:{col_let}9)")
                # 당년도 합계 수식
                elif r == 19 and c >= 2:
                    row_data.append(f"=SUM({col_let}13:{col_let}20)")
                else:
                    it = self.table.item(r, c)
                    val = it.text().replace(',', '').strip() if it else ""
                    # 엑셀 수식 기호 보호
                    if val.startswith(('=', '-', '+')): val = "'" + val
                    row_data.append(val)
            lines.append("\t".join(row_data))
            
        QApplication.clipboard().setText("\n".join(lines))
        


    def show_context_menu(self, pos):
        menu = QMenu()
        cp = menu.addAction("복사 (Ctrl+C)")
        ps = menu.addAction("붙여넣기 (Ctrl+V)")
        
        # 마우스 클릭한 위치에 메뉴 띄우기
        act = menu.exec_(self.table.viewport().mapToGlobal(pos))
        
        if act == cp:
            self.copy_selection()
        elif act == ps:
            self.paste_selection()


    def paste_selection(self):
        txt = QApplication.clipboard().text(); curr = self.table.currentItem()
        if not txt or not curr: return
        self.table.blockSignals(True)
        for i, line in enumerate(txt.splitlines()):
            for j, val in enumerate(line.split('\t')):
                r, c = curr.row() + i, curr.column() + j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    it = self.table.item(r, c)
                    if it and (it.flags() & Qt.ItemIsEditable): it.setText(val.strip())
        self.table.blockSignals(False)
        self.calculate_s11(curr)

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Copy): self.copy_selection()
        elif event.matches(QKeySequence.Paste): self.paste_selection()
        else: super().keyPressEvent(event)
