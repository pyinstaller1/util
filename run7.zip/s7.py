from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QKeySequence

# [1] S7 전용 우측 정렬 델리게이트
class S7RightAlignedDelegate(QStyledItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        return editor
    def setModelData(self, editor, model, index):
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)

# [2] 천단위 콤마 및 소수점 대응 아이템
class S7ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if val is None or str(val).strip() == "": return ""
            if val == "0": return "0"
            try:
                clean_val = str(val).replace(',', '')
                num = float(clean_val)
                if num == int(num): return format(int(num), ",")
                else: return format(num, ",.2f") 
            except: return val
        return super().data(role)

class Sheet7Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_sky_blue = QColor(220, 235, 245) 
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        title = QLabel("hwp 19페이지: (3-3) 근속승진 및 증원소요인건비 대상 인원의 파악")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)
        
        self.table = QTableWidget(18, 15)
        
        months = [f"{i}월" for i in range(1, 13)]
        headers = ["구분", "직급"] + months + ["평균인원"]
        self.table.setHorizontalHeaderLabels(headers)

        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)

        self.table.verticalHeader().setDefaultSectionSize(26)
        self.table.verticalHeader().setFixedWidth(25)
        
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section {
                background-color: #f4f4f4; padding: 2px;
                border: 0px; border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: bold;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; border: 0px; 
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: normal;  /* 행 번호 글자 굵게 하지 않음 */
            }            
            QScrollBar:vertical { background: #f1f1f1; width: 16px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:vertical { background: #888888; min-height: 30px; border-radius: 2px; }
            QScrollBar:horizontal { background: #f1f1f1; height: 16px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:horizontal { background: #888888; min-width: 30px; border-radius: 2px; }
            QScrollBar::add-line, QScrollBar::sub-line { width: 0px; height: 0px; }
        """)

        self.table.verticalHeader().setDefaultAlignment(Qt.AlignCenter)


        self.delegate = S7RightAlignedDelegate(self.table)
        for i in range(2, 15): 
            self.table.setItemDelegateForColumn(i, self.delegate)

        self.setup_content()
        
        self.table.setColumnWidth(0, 50); self.table.setColumnWidth(1, 60)
        for i in range(2, 14): self.table.setColumnWidth(i, 50)
        self.table.setColumnWidth(14, 70)

        self.table.itemChanged.connect(self.calculate_s7)
        layout.addWidget(self.table)

    def setup_content(self):
        self.table.blockSignals(True)
        # 1. 직급 리스트 확장 (1~6직급 포함 총 9개 항목)
        ranks = ["1직급", "2직급", "3직급", "4직급", "5직급", "6직급", "... ...", "별도직군", "계"]
        num_ranks = len(ranks) # 9
        
        full_headers = ["구분", "직급"] + [f"{i}월" for i in range(1, 13)] + ["평균인원"]
        
        comment_text = (
            "hwp 19페이지: (3-3) 근속승진 및 증원소요인건비 대상 인원의 파악\n가. 정원 및 현원 차이\n\n"
            " * 당년도 증원소요인건비 대상 인원은 직급별 평균인원 계산을 위한 Template(3-2) 당년도 현원에서 ‘나. 근속승진’의 인원을 차감한 인원임.\n"
            " * 전년도 증원소요인건비 대상 인원은 전년도 양식(2024년 경영실적보고서 작성) (3-3)의 ‘다. 증원소요인건비 대상 인원’을 기재함.\n"
            " * 각 직급별 평균인원은 1월부터 12월까지의 인원 총계를 12로 나누어서 구하되 소수점 이하 둘째 자리에서 반올림함."
        )

        # 전체 행 수 설정 (전년도9 + 구분선1 + 제목1 + 당년도9 + 구분선1 + 주석1 = 22)
        self.table.setRowCount(22)

        for r in range(22):
            for c in range(15):
                # 특수 행 설정 (9:구분선, 10:중간제목, 20:구분선, 21:주석)
                if r in [9, 20]: 
                    item = QTableWidgetItem("")
                    item.setFlags(Qt.NoItemFlags); item.setBackground(Qt.white)
                elif r == 10: 
                    item = QTableWidgetItem(full_headers[c])
                    item.setTextAlignment(Qt.AlignCenter)
                    item.setBackground(QColor(244, 244, 244))
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    f = item.font(); f.setBold(True); item.setFont(f)
                elif r == 21:
                    item = QTableWidgetItem(comment_text if c == 0 else "")
                    item.setTextAlignment(Qt.AlignLeft | Qt.AlignTop)
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                else:
                    # 기본 입력 데이터 (천단위 콤마 아이템)
                    item = S7ThousandSeparatorItem("0")
                    item.setTextAlignment(Qt.AlignCenter if c < 2 else Qt.AlignRight | Qt.AlignVCenter)
                    
                    # 계 행(8, 19) 및 평균인원(14) 및 직급열(1) 배경색/잠금
                    if c == 1 or r == 8 or r == 19 or c == 14:
                        item.setBackground(self.base_sky_blue)
                        # '계' 행과 '평균인원' 열은 수정 불가, '직급' 열은 표시용
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        if r in [8, 19] or c == 14:
                            f = item.font(); f.setBold(True); item.setFont(f)
                    
                    # 구분 열 (0열) 설정
                    if c == 0:
                        item.setBackground(QColor(245, 245, 245))
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        if r == 0: item.setText("전년도")
                        elif r == 11: item.setText("당년도")

                    # 직급 열 (1열) 이름 채우기
                    if c == 1:
                        if 0 <= r <= 8: item.setText(ranks[r])
                        elif 11 <= r <= 19: item.setText(ranks[r-11])

                self.table.setItem(r, c, item)

        # 표 병합 및 높이 조정
        self.table.setSpan(21, 0, 1, 15) # 주석 병합
        self.table.setSpan(0, 0, 9, 1)  # 전년도 구분 병합
        self.table.setSpan(11, 0, 9, 1) # 당년도 구분 병합
        self.table.setRowHeight(9, 10); self.table.setRowHeight(20, 10)
        self.table.setRowHeight(21, 180) 
        
        self.table.blockSignals(False)

        

    def calculate_s7(self, item):
        row, col = item.row(), item.column()
        # 입력이 불필요한 행(계, 구분선, 제목줄, 주석) 및 열(구분, 직급, 평균) 제외
        if col < 2 or col == 14 or row in [8, 9, 10, 19, 20, 21]: return 
        
        self.table.blockSignals(True)
        try:
            # 5, 6직급이 추가되어 데이터 행이 8줄씩으로 늘어남
            if 0 <= row <= 7: 
                data_rows, sum_row = list(range(8)), 8
            elif 11 <= row <= 18: 
                data_rows, sum_row = list(range(11, 19)), 19
            else: 
                return

            # 1. 가로 평균 (1월~12월 / 12)
            row_sum = sum(float(self.table.item(row, c).text().replace(',', '') or 0) for c in range(2, 14))
            # 소수점 둘째 자리 반올림
            avg_val = round(row_sum / 12, 2)
            self.table.item(row, 14).setData(Qt.EditRole, avg_val)

            # 2. 세로 합계 (해당 월의 직급별 인원 합산)
            col_sum = sum(float(self.table.item(r, col).text().replace(',', '') or 0) for r in data_rows)
            self.table.item(sum_row, col).setData(Qt.EditRole, int(col_sum))

            # 3. 평균인원 열의 합계 (가로 평균들의 세로 합)
            total_avg = sum(float(self.table.item(r, 14).text().replace(',', '') or 0) for r in data_rows)
            self.table.item(sum_row, 14).setData(Qt.EditRole, round(total_avg, 2))
            
        except Exception as e:
            print(f"S7 Calc Error: {e}")
        finally: 
            self.table.blockSignals(False)

    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        min_r, max_r = min(r.topRow() for r in selection), max(r.bottomRow() for r in selection)
        min_c, max_c = min(r.leftColumn() for r in selection), max(r.rightColumn() for r in selection)
        lines = []

        # 헤더 복사
        if min_r == 0:
            h_row = []
            for c in range(min_c, max_c + 1):
                h_item = self.table.horizontalHeaderItem(c)
                h_row.append(h_item.text().replace('\n', ' ') if h_item else "")
            lines.append("\t".join(h_row))

        for r in range(min_r, max_r + 1):
            if r in [9, 10, 20, 21]:
                row_data = []
                for c in range(min_c, max_c + 1):
                    it = self.table.item(r, c)
                    row_data.append(it.text().replace('\n', ' ') if it else "")
                lines.append("\t".join(row_data)); continue
                
            row_data = []
            # 엑셀 행 번호 (프로그램 0행 = 엑셀 2행 기준)
            ex_r = r + 2

            for c in range(min_c, max_c + 1):
                col_let = chr(65 + c)
                
                # 1. 가로 평균 (평균인원 열)
                if c == 14 and r not in [8, 19]:
                    row_data.append(f"=ROUND(AVERAGE(C{ex_r}:N{ex_r}), 2)")
                
                # 2. 전년도 합계 (프로그램 8행 -> 엑셀 10행)
                # 데이터 범위: 엑셀 2행 ~ 9행 (9행이 별도직군)
                elif r == 8 and c >= 2:
                    row_data.append(f"=SUM({col_let}2:{col_let}9)")
                
                # 3. 당년도 합계 (프로그램 19행 -> 엑셀 21행)
                # 데이터 범위: 엑셀 13행 ~ 20행 (20행이 별도직군)
                elif r == 19 and c >= 2:
                    row_data.append(f"=SUM({col_let}13:{col_let}20)")
                
                else:
                    it = self.table.item(r, c)
                    val = it.text().replace(',', '').strip() if it else ""
                    if val.startswith(('=', '-', '+')): val = "'" + val
                    row_data.append(val)
            lines.append("\t".join(row_data))
            
        QApplication.clipboard().setText("\n".join(lines))



        

    def paste_selection(self):
        txt = QApplication.clipboard().text(); curr = self.table.currentItem()
        if not txt or not curr: return
        self.table.blockSignals(True)
        for i, line in enumerate(txt.splitlines()):
            for j, val in enumerate(line.split('\t')):
                r, c = curr.row() + i, curr.column() + j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    it = self.table.item(r, c)
                    if it and (it.flags() & Qt.ItemIsEditable): it.setText(val.strip())
        self.table.blockSignals(False)
        self.calculate_s7(curr)

    def show_context_menu(self, pos):
        menu = QMenu(); cp = menu.addAction("복사 (Ctrl+C)"); ps = menu.addAction("붙여넣기 (Ctrl+V)")
        act = menu.exec_(self.table.viewport().mapToGlobal(pos))
        if act == cp: self.copy_selection()
        elif act == ps: self.paste_selection()

        

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Copy): self.copy_selection()
        elif event.matches(QKeySequence.Paste): self.paste_selection()
        else: super().keyPressEvent(event)
