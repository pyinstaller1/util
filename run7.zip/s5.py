from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QKeySequence, QFont

class s5RightAlignedDelegate(QStyledItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        return editor
    def setModelData(self, editor, model, index):
        model.setData(index, editor.text().replace(',', ''), Qt.EditRole)

class s5ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if val is None or str(val).strip() == "": return ""
            try:
                num = float(str(val).replace(',', ''))
                # 정수면 콤마만, 소수면 소수점 2자리까지
                return format(int(num), ",") if num == int(num) else format(num, ",.2f")
            except: return val
        return super().data(role)

class Sheet5Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_sky_blue = QColor(220, 235, 245)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        title = QLabel("hwp 17페이지: (3-3) 근속승진 및 증원소요인건비 대상 인원의 파악")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)
        
        self.table = QTableWidget(18, 26)
        self.setup_style()
        self.setup_headers()
        self.setup_content()

        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)
        
        delegate = s5RightAlignedDelegate(self.table)
        for c in range(2, 26):
            self.table.setItemDelegateForColumn(c, delegate)

        self.table.itemChanged.connect(self.calculate_diff)
        layout.addWidget(self.table)

    def setup_style(self):
        self.table.verticalHeader().setDefaultSectionSize(28)
        self.table.verticalHeader().setFixedWidth(25)

        
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            
            /* 헤더 스타일 */
            QHeaderView::section {
                background-color: #f4f4f4; padding: 2px;
                border: 0px; border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: bold;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; border: 0px; 
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: normal;
            }

            /* 가로 스크롤바 스타일 개선 */
            QScrollBar:horizontal {
                border: 1px solid #d0d0d0;
                background: #f0f0f0;
                height: 12px;
                margin: 0px 0px 0px 0px;
            }
            QScrollBar::handle:horizontal {
                background: #bcbcbc; /* 스크롤 핸들 색상 (진한 회색) */
                min-width: 20px;
                border-radius: 5px;
            }
            QScrollBar::handle:horizontal:hover {
                background: #a0a0a0; /* 마우스 올렸을 때 더 진하게 */
            }

            /* 세로 스크롤바 스타일 개선 */
            QScrollBar:vertical {
                border: 1px solid #d0d0d0;
                background: #f0f0f0;
                width: 12px;
                margin: 0px 0px 0px 0px;
            }
            QScrollBar::handle:vertical {
                background: #bcbcbc;
                min-height: 20px;
                border-radius: 5px;
            }
            QScrollBar::handle:vertical:hover {
                background: #a0a0a0;
            }
            
            /* 스크롤바 상하단 화살표 제거 (더 깔끔하게) */
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical,
            QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
                width: 0px; height: 0px;
            }
            
        """)



    def setup_headers(self):
        h_labels = ["구분", "직급"]
        for m in range(1, 7):
            for sub in ["정원", "현원", "복직자", "누적차"]:
                h_labels.append(f"{m}월\n{sub}")
        self.table.setHorizontalHeaderLabels(h_labels)
        self.table.horizontalHeader().setFixedHeight(45)
        
        self.table.setColumnWidth(0, 30) 
        self.table.setColumnWidth(1, 60)
        for c in range(2, 26): self.table.setColumnWidth(c, 50)

    def setup_content(self):
        self.table.blockSignals(True)
        # 1. 직급 리스트 확장
        ranks = ["1직급", "2직급", "3직급", "4직급", "5직급", "6직급", "... ...", "별도직군", "계"]
        num_ranks = len(ranks) # 9개
        
        # 2. 전체 행 수 조정 (표 2개 + 구분선 + 제목 + 주석 등)
        self.table.setRowCount(22)

        # 3. 첫 번째 표 (당년도 병합)
        year_item1 = QTableWidgetItem("당\n년\n도")
        year_item1.setTextAlignment(Qt.AlignCenter)
        year_item1.setBackground(QColor(245, 245, 245)) # 직접 색상 지정
        year_item1.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        self.table.setItem(0, 0, year_item1)
        self.table.setSpan(0, 0, num_ranks, 1)

        for r, rank in enumerate(ranks):
            self.create_row_items(r, rank)
        
        self.table.setRowHeight(num_ranks, 15) # 구분선 (9행)

        # 4. 두 번째 표 제목 (10행)
        title_row_idx = num_ranks + 1 # 10
        h_font = QFont(); h_font.setBold(True)
        for c in range(26):
            it = QTableWidgetItem()
            it.setBackground(QColor(240, 240, 240))
            it.setFont(h_font)
            it.setTextAlignment(Qt.AlignCenter)
            if c == 0: it.setText("구분")
            elif c == 1: it.setText("직급")
            else:
                m = 7 + (c-2)//4
                sub = ["정원", "현원", "복직자", "누적차"][(c-2)%4]
                it.setText(f"{m}월\n{sub}")
            self.table.setItem(title_row_idx, c, it)
        self.table.setRowHeight(title_row_idx, 45)

        # 5. 두 번째 표 데이터 (11~19행)
        data2_start_idx = title_row_idx + 1 # 11
        year_item2 = QTableWidgetItem("당\n년\n도")
        year_item2.setTextAlignment(Qt.AlignCenter)
        year_item2.setBackground(QColor(245, 245, 245)) # 직접 색상 지정
        year_item2.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        self.table.setItem(data2_start_idx, 0, year_item2)
        self.table.setSpan(data2_start_idx, 0, num_ranks, 1)

        for r, rank in enumerate(ranks):
            self.create_row_items(data2_start_idx + r, rank)

        # 6. 자동 계산 영역(누적차 열, 계 행) 파란색 및 잠금 설정
        for r in range(self.table.rowCount()):
            rank_it = self.table.item(r, 1)
            if not rank_it: continue
            for c in range(2, 26):
                item = self.table.item(r, c)
                if not item: continue
                # 누적차 열이거나 '계' 행인 경우
                if (c - 2) % 4 == 3 or rank_it.text() == "계":
                    item.setBackground(self.base_sky_blue)
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable)

        # 7. 주석 위치 (21행)
        self.table.setRowHeight(data2_start_idx + num_ranks, 15)
        self.table.setSpan(21, 0, 1, 26)
        self.table.setRowHeight(21, 128)
        
        self.table.blockSignals(False)



        
        
    def create_row_items(self, row, rank):
        # 굵은 글씨 폰트 객체 생성
        bold_font = QFont()
        bold_font.setBold(True)

        # 직급열 (B열, 인덱스 1)
        it_rank = QTableWidgetItem(rank)
        it_rank.setTextAlignment(Qt.AlignCenter)
        it_rank.setBackground(self.base_sky_blue)
        it_rank.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        if rank == "계":
            it_rank.setFont(bold_font) # '계' 글자 굵게
        self.table.setItem(row, 1, it_rank)

        # 데이터열 (C열~, 인덱스 2~25)
        for c in range(2, 26):
            if (c - 2) % 4 == 3 or rank == "계":
                it = s5ThousandSeparatorItem("0") # '계' 줄도 콤마 적용을 위해 변경
                it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                it.setBackground(self.base_sky_blue)
                it.setFont(bold_font) # '계' 행의 모든 숫자 굵게
                it.setForeground(QColor("#000000")) # 더 진한 검정색
            else:
                it = s5ThousandSeparatorItem("0")
            
            it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.table.setItem(row, c, it)

            
    def cell_value(self, r, c):
        it = self.table.item(r, c)
        if not it: return 0.0
        txt = it.text().replace(',', '').strip()
        try: return float(txt)
        except: return 0.0

    def calculate_diff(self, item):
        r, c = item.row(), item.column()
        # 데이터 입력창이 아닌 행(구분선, 제목줄, 주석)은 계산에서 제외
        if c < 2 or (c - 2) % 4 == 3 or r in [9, 10, 20, 21]: return 
        
        self.table.blockSignals(True)
        try:
            month_base = 2 + ((c - 2) // 4) * 4
            # 표1은 0~8행(계=8), 표2는 11~19행(계=19)
            is_first_table = r < 9
            start_row = 0 if is_first_table else 11
            last_row = start_row + 8  # '계' 행 위치
            
            # 1. 직급별 누적차 계산 (1~6직급, ..., 별도직군까지 순차 누적)
            for row in range(start_row, last_row):
                acc = 0
                for rr in range(start_row, row + 1):
                    # 정원 - 현원 + 복직자
                    acc += (self.cell_value(rr, month_base) - 
                            self.cell_value(rr, month_base + 1) + 
                            self.cell_value(rr, month_base + 2))
                diff_it = self.table.item(row, month_base + 3)
                if diff_it:
                    diff_it.setData(Qt.EditRole, int(acc)) 
                    diff_it.setForeground(QColor("red") if acc < 0 else QColor("black"))
            
            # 2. 세로 합계 (정원, 현원, 복직자) - 계 행(last_row)에 반영
            for off in range(3):
                col_idx = month_base + off
                v_sum = sum(self.cell_value(start_row + i, col_idx) for i in range(8)) # 8개 직급 합산
                self.table.item(last_row, col_idx).setData(Qt.EditRole, int(v_sum))
                
            # 3. 누적차 계 (마지막 직급인 별도직군의 누적차 값을 그대로 가져옴)
            last_val = self.cell_value(last_row - 1, month_base + 3)
            self.table.item(last_row, month_base + 3).setData(Qt.EditRole, int(last_val))
            self.table.item(last_row, month_base + 3).setForeground(
                self.table.item(last_row - 1, month_base + 3).foreground()
            )
            
        finally: 
            self.table.blockSignals(False)

    def col_letter(self, idx):
        return chr(65 + idx)

    def copy_selection(self):
        ranges = self.table.selectedRanges()
        if not ranges: return
        r0, r1 = min(r.topRow() for r in ranges), max(r.bottomRow() for r in ranges)
        c0, c1 = min(r.leftColumn() for r in ranges), max(r.rightColumn() for r in ranges)
        lines = []

        # 1. 가로 헤더(최상단 타이틀) 복사: 첫 번째 행(0행)이 선택 범위에 포함된 경우
        if r0 == 0:
            header_row = []
            for c in range(c0, c1 + 1):
                h_item = self.table.horizontalHeaderItem(c)
                # 헤더 텍스트의 줄바꿈(\n)을 공백으로 치환하여 엑셀 한 셀에 넣음
                header_row.append(h_item.text().replace('\n', ' ') if h_item else "")
            lines.append("\t".join(header_row))

        # 2. 본문 및 중간 제목줄 복사
        for r in range(r0, r1 + 1):
            row_data = []
            
            # 5, 6직급 추가 기준 특수 행 (9:구분선, 10:두번째 표 제목, 20:구분선, 21:주석)
            if r in [9, 10, 20, 21]:
                for c in range(c0, c1 + 1):
                    it = self.table.item(r, c)
                    # 표 중간에 있는 제목줄(10행) 등도 줄바꿈 제거 후 복사
                    row_data.append(it.text().replace('\n', ' ') if it else "")
                lines.append("\t".join(row_data))
                continue

            # --- 이하 데이터 행 계산 및 수식 로직 ---
            is_first_table = r < 9
            is_total_row = (r == 8 or r == 19) # '계' 행
            excel_r = r + 2 # 엑셀 행 번호 보정 (헤더가 1행이므로 +2)
            
            data_start_r = 2 if is_first_table else 13
            data_end_r = 10 if is_first_table else 21

            for c in range(c0, c1 + 1):
                it = self.table.item(r, c)
                col_let = self.col_letter(c)
                
                # 누적차 수식
                if c >= 2 and (c-2)%4 == 3 and not is_total_row:
                    m_base = 2 + ((c-2)//4)*4
                    formula = (f"=SUM({self.col_letter(m_base)}${data_start_r}:{self.col_letter(m_base)}{excel_r})-"
                               f"SUM({self.col_letter(m_base+1)}${data_start_r}:{self.col_letter(m_base+1)}{excel_r})+"
                               f"SUM({self.col_letter(m_base+2)}${data_start_r}:{self.col_letter(m_base+2)}{excel_r})")
                    row_data.append(formula)
                
                # 계 행 수식
                elif is_total_row and c >= 2:
                    if (c-2)%4 == 3: row_data.append(f"={col_let}{excel_r-1}")
                    else: row_data.append(f"=SUM({col_let}{data_start_r}:{col_let}{data_end_r-1})")
                
                # 일반 텍스트/숫자
                else:
                    txt = it.text().replace(',', '').replace('\n', ' ') if it else ""
                    val = "'" + txt if txt.startswith(('-', '+', '=')) else txt
                    row_data.append(val)
            
            lines.append("\t".join(row_data))

        # 클립보드로 전송
        QApplication.clipboard().setText("\n".join(lines))


        


        

    def paste_selection(self):
        text = QApplication.clipboard().text(); curr = self.table.currentItem()
        if not text or not curr: return
        self.table.blockSignals(True)
        for i, line in enumerate(text.splitlines()):
            if "월" in line and "정원" in line: continue
            for j, val in enumerate(line.split('\t')):
                r, c = curr.row() + i, curr.column() + j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    it = self.table.item(r, c)
                    if it and (it.flags() & Qt.ItemIsEditable):
                        it.setText(val.split('=')[-1] if '=' in val else val)
        self.table.blockSignals(False)
        self.calculate_diff(curr)

    def show_context_menu(self, pos):
        menu = QMenu(self)
        menu.setStyleSheet("""
            QMenu {
                background-color: white;
                border: 1px solid #c0c0c0;
            }
            QMenu::item {
                padding: 6px 25px;
                color: black;
            }
            QMenu::item:selected {
                background-color: #5fa8f5;
                color: white;
            }
        """)

        menu.addAction("복사", self.copy_selection)
        menu.addAction("붙여넣기", self.paste_selection)
        menu.exec_(self.table.viewport().mapToGlobal(pos))

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Copy): self.copy_selection()
        elif event.matches(QKeySequence.Paste): self.paste_selection()
        else: super().keyPressEvent(event)
