import time
import pygetwindow as gw
from pywinauto import Application
import pyautogui
import numpy as np
import cv2
import easyocr
import re
import psutil
import subprocess





left, top, width, height = 0, 0, 0, 0
che, do = 1000, 1000
bok = 0
wins = None
app = None















def login_jo():
    # LDPlayer 닫기
    for win in gw.getWindowsWithTitle('LDPlayer'):
        if win.title.strip():
            win.close()


    # 멀티 매니저 실행하기
    is_running = any(p.name() == "dnmultiplayerex.exe" for p in psutil.process_iter())
    if is_running:
        print("멀티 매니저가 실행 중입니다.")
    else:
        print("멀티 매니저가 실행 중이 아닙니다. 실행을 시작합니다...")
        try:
            subprocess.Popen(r"C:\LDPlayer\ldmutiplayer\dnmultiplayerex.exe", shell=True)  # 프로그램 실행
            print("멀티 매니저를 실행했습니다.")
        except Exception as e:
            print(f"멀티 매니저 실행 중 오류 발생: {e}")
            

    # 실행 버튼 누르기
    time.sleep(3)
    win = gw.getWindowsWithTitle('멀티 매니저')[0]


    # 멀티 매니저창 활성화
    app_manager = Application().connect(handle=win._hWnd)
    app_manager.window(handle=win._hWnd).set_focus()

    pyautogui.moveTo(win.left+(win.width*0.78), win.top+(win.height*0.30), 2.0)   # 실행 버튼
    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()

    time.sleep(30)






    # LD플레이어 화면
    global wins
    wins = [win for win in gw.getWindowsWithTitle('LDPlayer') if win.title.strip()]   # LD플레이어 윈도우 목록 가져오기


    if not wins:
        print("윈도우를 찾을 수 없습니다.")

    for i, win in enumerate(wins):
        print(f"{i + 1}: {win.title} (위치: {win.left}, {win.top}, 크기: {win.width}x{win.height})")


    choice = 0  # 첫 번째 윈도우 선택
    win = wins[choice]
    print(win.title)

    global app
    app = Application().connect(handle=win._hWnd)
    app.window(handle=win._hWnd).set_focus()


    global left, top, width, height
    left = win.left
    top = win.top
    width = win.width
    height = win.height


    # 광고 닫기
    pyautogui.moveTo(left+(width*0.75), top+(height*0.25), 2.0)
    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()

    time.sleep(3)


    # 조선협객전을 OCR로 찾기
    scr_start = pyautogui.screenshot(region=(left+int(width*0.25), top+int(height*0.317), int(width*0.38), int(height*0.03)))
    scr_start_np = np.array(scr_start)
    scr_start.save("scr_start.png")

    reader = easyocr.Reader(['ko', 'en'], gpu=False)
    results = reader.readtext(scr_start_np)

    str_start = ""
    x_start = 0
    y_start = 0

    for detection in results:
        bbox, text, confidence = detection
        top_left = bbox[0]
        bottom_right = bbox[2]
        x = (top_left[0] + bottom_right[0]) // 2
        y = (top_left[1] + bottom_right[1]) // 2

        if "조선" in text or "협객" in text or "객전" in text:
            str_start = text
            x_start = x
            y_start = y
            continue

    # 조선협객전 클릭
    pyautogui.moveTo(left+int(width*0.25) + x_start, top+int(height*0.318) + y_start - int(height*0.057), 2.0)   # 바탕화면
    pyautogui.mouseDown()
    time.sleep(0.1)
    pyautogui.mouseUp()

    time.sleep(1)
    
    pyautogui.mouseDown()
    time.sleep(0.1)
    pyautogui.mouseUp()

    time.sleep(1)

    pyautogui.mouseDown()
    time.sleep(0.1)
    pyautogui.mouseUp()

    time.sleep(30)


    # 건너뛰기
    pyautogui.moveTo(left+(width*0.87), top+(height*0.10), 2.0) # 건너뛰기
    pyautogui.mouseDown()
    time.sleep(0.1)
    pyautogui.mouseUp()

    time.sleep(0.1)
    
    pyautogui.mouseDown()
    time.sleep(0.1)
    pyautogui.mouseUp()
    
    time.sleep(5)


    # 입장
    pyautogui.moveTo(left+(width*0.5), top+(height*0.7), 2.0) # 메뉴
    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()

    time.sleep(1)



    ###   접속대기 화면인지 ocr
    """
    # 접속 대기
    for i in range(50):
        # scr_wait = pyautogui.screenshot(region=(left+int(width*0.5), top+int(height*0.65), 10, 10))
        scr_wait = pyautogui.screenshot(region=(left+int(width*0.83), top+int(height*0.91), 10, 10))

        scr_wait_np = np.array(scr_wait)
        hsv = cv2.cvtColor(scr_wait_np, cv2.COLOR_RGB2HSV)

        scr_wait.save("scr_wait.png")

        # 빨간색 픽셀 탐지
        mask = cv2.bitwise_or(
            cv2.inRange(hsv, np.array([0, 50, 50]), np.array([10, 255, 255])),
            cv2.inRange(hsv, np.array([170, 50, 50]), np.array([180, 255, 255]))
            )
        # scr_check01.save('scr.png')
        if not np.any(mask):
            print("게임 시작 빨간색 계열이 없습니다.")
            time.sleep(60)
        else:
            print("게임 시작")
            break
        return
        time.sleep(5)
    """


    time.sleep(10)
    
    # 케릭터 선택
    pyautogui.moveTo(left+(width*0.83), top+(height*0.91), 2.0)   # 게임 시작
    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()   

    time.sleep(38)


    # 미션 건너뛰기
    pyautogui.moveTo(left+(width*0.89), top+(height*0.63), 2.0)   # 건너뛰기
    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()

    time.sleep(5)
    
    pyautogui.moveTo(left+(width*0.38), top+(height*0.91), 2.0)   # 취소
    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()

    p02_bok()    
    p03_jangbi()


            
            






def p01_start():
    print("p01_start")

    global wins
    wins = [win for win in gw.getWindowsWithTitle('LDPlayer') if win.title.strip()]   # LD플레이어 윈도우 목록 가져오기

    if not wins:
        print("윈도우를 찾을 수 없습니다.")

    for i, win in enumerate(wins):
        print(f"{i + 1}: {win.title} (위치: {win.left}, {win.top}, 크기: {win.width}x{win.height})")


    choice = 0  # 첫 번째 윈도우 선택
    win = wins[choice]
    print(win.title)

    global app
    app = Application().connect(handle=win._hWnd)
    app.window(handle=win._hWnd).set_focus()


    global left, top, width, height
    left = win.left
    top = win.top
    width = win.width
    height = win.height


    # 화면 캡처
    screenshot = pyautogui.screenshot(region=(left, top, width, height))
    screenshot_np = np.array(screenshot)
    screenshot_gray = cv2.cvtColor(screenshot_np, cv2.COLOR_RGB2GRAY)
    

    scr_check01 = pyautogui.screenshot(region=(left, top+(height-20), 10, 10))
    scr_check01_np = np.array(scr_check01)
    hsv = cv2.cvtColor(scr_check01_np, cv2.COLOR_RGB2HSV)

    # 빨간색 픽셀 탐지
    mask = cv2.bitwise_or(
        cv2.inRange(hsv, np.array([0, 50, 50]), np.array([10, 255, 255])),
        cv2.inRange(hsv, np.array([170, 50, 50]), np.array([180, 255, 255]))
    )

    # scr_check01.save('scr.png')


    if np.any(mask):
        print("빨간색 계열이 발견되었습니다.")

        pyautogui.moveTo(left+(width*0.478), top+(height*0.88), 2.0) # 부활하기

        pyautogui.mouseDown()
        time.sleep(1)
        pyautogui.mouseUp()

        global bok
        bok = 1

        time.sleep(60)
    else:
        time.sleep(3)




def p02_bok():
    print("p02_bok")

    global left, top, width, height


    # s02_bok
    # 절전 모드 해제
    pyautogui.moveTo(left+(width*0.433), top+(height*0.88), 2.0)
    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.moveTo(left+(width*0.53), top+(height*0.88), 2.0)
    pyautogui.mouseUp()

    time.sleep(3)
    

    # 복구 확인
    scr_bok = pyautogui.screenshot(region=(left+int(width*0.715), top+int(height*0.035), int(width*0.02), int(height*0.03)))
    scr_bok.save('bok.png')


    scr_bok_np = np.array(scr_bok)

    hsv = cv2.cvtColor(scr_bok_np, cv2.COLOR_RGB2HSV)





    # 복구 빨간색 픽셀 탐지
    mask = cv2.bitwise_or(
        cv2.inRange(hsv, np.array([0, 50, 50]), np.array([10, 255, 255])),
        cv2.inRange(hsv, np.array([170, 50, 50]), np.array([180, 255, 255]))
    )





    global bok
    if np.any(mask) or bok == 1:
        print("복구 빨간색 계열이 발견되었습니다.")
        bok = 0

        # 복구
        pyautogui.moveTo(left+(width*0.71), top+(height*0.07), 2.0) # 복구
        pyautogui.mouseDown()
        time.sleep(1)
        pyautogui.mouseUp()
        

        pyautogui.moveTo(left+(width*0.17), top+(height*0.9), 2.0) # 복구
        pyautogui.mouseDown()
        time.sleep(1)
        pyautogui.mouseUp()
        
        pyautogui.moveTo(left+(width*0.57), top+(height*0.65), 2.0) # 확인 버튼
        pyautogui.mouseDown()
        time.sleep(0.3)
        pyautogui.mouseUp()

        pyautogui.moveTo(left+(width*0.17), top+(height*0.9), 2.0) # 복구
        pyautogui.mouseDown()
        time.sleep(1)
        pyautogui.mouseUp()

        pyautogui.moveTo(left+(width*0.57), top+(height*0.65), 2.0) # 확인 버튼        
        pyautogui.mouseDown()
        time.sleep(0.3)
        pyautogui.mouseUp()



        cnt_energy = 0
        print("체력, 도력 그래픽 체크")
        
        for i in range(10):
            if cnt_energy > 2:
                continue

            scr_energy = pyautogui.screenshot(region=(left+int(width*0.223), top+int(height*0.1), 117, 17))
            scr_energy_np = np.array(scr_energy)
            scr_energy.save("scr_energy.png")

            reader = easyocr.Reader(['ko', 'en'], gpu=False)
            results = reader.readtext(scr_energy_np)

            print(results)
            list_energy = [0, 0]
            if len(results) == 2:
                cnt_energy += 1
                for idx, detection in enumerate(results):
                    bbox, text, confidence = detection

                    if list_energy[idx] < list(map(int, re.findall(r'\d+', text.replace(".", "").replace(",", ""))))[0]:
                        list_energy[idx] = list(map(int,re.findall(r'\d+', text.replace(".", "").replace(",", ""))))[0]

        global che, do                        
        che = list_energy[0]
        do = list_energy[1]
        print(che*10000+do)



        ###
        # 체력   도력 < 100
        ###


        if che < 100 or do < 100:   # 체력, 도력이 100보다 작으면 (체력, 도력 그래픽 확인)
            #잡화상인에게 이동


 
            pyautogui.moveTo(left+(width*0.81), top+(height*0.25), 2.0) # 지도
            pyautogui.mouseDown()
            time.sleep(2)
            pyautogui.mouseUp()
            
            pyautogui.moveTo(left+(width*0.80), top+(height*0.25), 2.0)
            pyautogui.mouseDown()
            time.sleep(2)
            pyautogui.mouseUp()
            time.sleep(2)
            

            pyautogui.moveTo(left+(width*0.80), top+(height*0.32), 2.0) # 개경 마을
            pyautogui.mouseDown()
            time.sleep(2)
            pyautogui.mouseUp()
            time.sleep(1)

            pyautogui.moveTo(left+(width*0.80), top+(height*0.37), 2.0) # 잡화 상인
            pyautogui.mouseDown()
            time.sleep(2)
            pyautogui.mouseUp()

            time.sleep(2)

            pyautogui.moveTo(left+(width*0.80), top+(height*0.95), 2.0) # 이동 버튼
            pyautogui.mouseDown()
            time.sleep(2)
            pyautogui.mouseUp()
            time.sleep(5)
            


            # 잡화상인 선택
            scr_heal = pyautogui.screenshot(region=(left+int(width*0.25), top+int(height*0.25), int(width*0.3), int(height*0.3)))
            scr_heal_np = np.array(scr_heal)
            # scr_heal.save("scr_heal.png")


            # OCR 객체 생성 및 텍스트 추출
            reader = easyocr.Reader(['ko', 'en'], gpu=False)
            results = reader.readtext(scr_heal_np)

            str_heal = ""
            x_heal = 0
            y_heal = 0

            # 텍스트와 중심 좌표 출력
            print("OCR 텍스트 및 좌표:")
            for detection in results:
                bbox, text, confidence = detection
                top_left = bbox[0]
                bottom_right = bbox[2]
                x = (top_left[0] + bottom_right[0]) // 2
                y = (top_left[1] + bottom_right[1]) // 2
                print(f"{text} [{x}, {y}]")

                if "[" in text or "]" in text or "잡화" in text or "집화" in text:
                    str_heal = text
                    x_heal = x
                    y_heal = y
                    continue

            pyautogui.moveTo(left+int(width*0.25) + x_heal, top+int(height*0.26) + y_heal + int(height*0.07), 2.0)   # 잡화 상인
            pyautogui.mouseDown()
            time.sleep(1)
            pyautogui.mouseUp()

            pyautogui.moveTo(left+(width*0.33), top+(height*0.85), 2.0)   # 상점 이용
            pyautogui.mouseDown()
            time.sleep(1)
            pyautogui.mouseUp()
            time.sleep(2)


            # 체력, 도력 회복제 구매
            pyautogui.moveTo(left+(width*0.17), top+(height*0.70), 2.0)   # 상품
            pyautogui.mouseDown()
            time.sleep(1)

            pyautogui.moveTo(left+(width*0.17), top+(height*0.38), 2.0)   # 상품
            pyautogui.mouseUp()


            # 체력 회복제 구매
            if che < 100:
                time.sleep(2)
                pyautogui.moveTo(left+(width*0.20), top+(height*0.615), 2.0)   # 체력 회복제
                pyautogui.mouseDown()
                time.sleep(1)
                pyautogui.mouseUp()

                pyautogui.moveTo(left+(width*0.58), top+(height*0.80), 2.0)   # 구매
                pyautogui.mouseDown()
                time.sleep(1)
                pyautogui.mouseUp()


                pyautogui.moveTo(left+(width*0.58), top+(height*0.73), 2.0)   # +1000
                pyautogui.mouseDown()
                time.sleep(1)
                pyautogui.mouseUp()


                pyautogui.moveTo(left+(width*0.55), top+(height*0.83), 2.0)   # 확인
                pyautogui.mouseDown()
                time.sleep(1)
                pyautogui.mouseUp()
                


            # 도력 회복제 구매
            if do < 100:
                time.sleep(2)
                pyautogui.moveTo(left+(width*0.17), top+(height*0.80), 2.0)   # 상품
                pyautogui.mouseDown()
                time.sleep(1)

                pyautogui.moveTo(left+(width*0.17), top+(height*0.30), 2.0)   # 상품
                pyautogui.mouseUp()

                pyautogui.moveTo(left+(width*0.20), top+(height*0.671), 2.0)   # 도력 회복제
                pyautogui.mouseDown()
                time.sleep(1)
                pyautogui.mouseUp()

                pyautogui.moveTo(left+(width*0.58), top+(height*0.80), 2.0)   # 구매
                pyautogui.mouseDown()
                time.sleep(1)
                pyautogui.mouseUp()

                pyautogui.moveTo(left+(width*0.58), top+(height*0.73), 2.0)   # +1000
                pyautogui.mouseDown()
                time.sleep(1)
                pyautogui.mouseUp()


                pyautogui.moveTo(left+(width*0.55), top+(height*0.83), 2.0)   # 확인
                pyautogui.mouseDown()
                time.sleep(1)
                pyautogui.mouseUp()


            pyautogui.moveTo(left+(width*0.55), top+(height*0.93), 2.0)   # 구매
            pyautogui.mouseDown()
            time.sleep(1)
            pyautogui.mouseUp()

            pyautogui.moveTo(left+(width*0.57), top+(height*0.65), 2.0) # 확인 버튼
            pyautogui.mouseDown()
            time.sleep(0.3)
            pyautogui.mouseUp()

            pyautogui.moveTo(left+(width*0.95), top+(height*0.07), 2.0) # 종료
            pyautogui.mouseDown()
            time.sleep(1)
            pyautogui.mouseUp()





        # 사냥도감
        pyautogui.moveTo(left+(width*0.95), top+(height*0.07), 2.0) # 메뉴
        pyautogui.mouseDown()
        time.sleep(1)
        pyautogui.mouseUp()


        pyautogui.moveTo(left+(width*0.95), top+(height*0.18), 2.0) # 사냥도감
        pyautogui.mouseDown()
        time.sleep(0.3)
        pyautogui.mouseUp()


        pyautogui.moveTo(left+(width*0.055), top+(height*0.46), 2.0) # 요도우라   36  46  56  63  70  78 
        pyautogui.mouseDown()
        time.sleep(0.3)
        pyautogui.mouseUp()


        pyautogui.moveTo(left+(width*0.17), top+(height*0.33), 2.0) # 맷돼지
        pyautogui.mouseDown()
        time.sleep(0.3)
        pyautogui.mouseUp()


        pyautogui.moveTo(left+(width*0.91), top+(height*0.95), 2.0) # 이동
        pyautogui.mouseDown()
        time.sleep(0.3)
        pyautogui.mouseUp()


        pyautogui.moveTo(left+(width*0.57), top+(height*0.65), 2.0) # 확인 버튼
        
        pyautogui.mouseDown()
        time.sleep(0.3)
        pyautogui.mouseUp()


        time.sleep(60)


        # AUTO 버튼
        pyautogui.moveTo(left+(width*0.915), top+(height*0.73), 2.0) # AUTO 버튼
        pyautogui.mouseDown()
        time.sleep(0.3)
        pyautogui.mouseUp()


def p03_jangbi():
    print("p03_jangbi")

    global left, top, width, height


    # 장비 도감
    pyautogui.moveTo(left+(width*0.95), top+(height*0.07), 2.0) # 메뉴
    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()


    pyautogui.moveTo(left+(width*0.76), top+(height*0.28), 2.0) # 장비도감
    pyautogui.mouseDown()
    time.sleep(0.3)
    pyautogui.mouseUp()


    pyautogui.moveTo(left+(width*0.83), top+(height*0.93), 2.0) # 장비도감 일괄등록
    pyautogui.mouseDown()
    time.sleep(0.3)
    pyautogui.mouseUp()


    pyautogui.moveTo(left+(width*0.57), top+(height*0.65), 2.0) # 확인 버튼
    pyautogui.mouseDown()
    time.sleep(0.3)
    pyautogui.mouseUp()

    time.sleep(3.0)

    
    pyautogui.mouseDown()
    time.sleep(0.3)
    pyautogui.mouseUp()


    pyautogui.moveTo(left+(width*0.96), top+(height*0.08), 2.0) # 장비도감 종료
    pyautogui.mouseDown()
    time.sleep(0.3)
    pyautogui.mouseUp()







    # 가방 분해
    pyautogui.moveTo(left+(width*0.95), top+(height*0.07), 2.0) # 메뉴

    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()


    pyautogui.moveTo(left+(width*0.80), top+(height*0.08), 2.0) # 가방

    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()




    pyautogui.moveTo(left+(width*0.75), top+(height*0.18), 2.0) # 장비

    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()


    pyautogui.moveTo(left+(width*0.91), top+(height*0.76), 2.0) # 장비선택
    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()
    

    pyautogui.moveTo(left+(width*0.61), top+(height*0.25), 2.0) # 쓰레기통
    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()

    pyautogui.moveTo(left+(width*0.56), top+(height*0.67), 2.0) # 삭제버튼
    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()


    pyautogui.moveTo(left+(width*0.91), top+(height*0.76), 2.0) # 장비선택
    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()

    pyautogui.moveTo(left+(width*0.61), top+(height*0.25), 2.0) # 쓰레기통
    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()

    pyautogui.moveTo(left+(width*0.56), top+(height*0.67), 2.0) # 삭제버튼
    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()
    




    pyautogui.moveTo(left+(width*0.81), top+(height*0.925), 2.0) # 분해

    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()
    

    pyautogui.moveTo(left+(width*0.417), top+(height*0.638), 2.0) # 장비

    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()

    pyautogui.moveTo(left+(width*0.417), top+(height*0.68), 2.0) # 일반

    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()

    pyautogui.moveTo(left+(width*0.47), top+(height*0.68), 2.0) # 고급

    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()


    pyautogui.moveTo(left+(width*0.57), top+(height*0.81), 2.0) # 분해버튼

    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()
    


    pyautogui.moveTo(left+(width*0.56), top+(height*0.638), 2.0) # 확인버튼

    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()
    
    pyautogui.moveTo(left+(width*0.50), top+(height*0.67), 2.0) # 확인버튼

    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()


    pyautogui.moveTo(left+(width*0.388), top+(height*0.81), 2.0) # 취소버튼

    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()


    pyautogui.moveTo(left+(width*0.287), top+(height*0.167), 2.3) # X버튼

    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()


    pyautogui.moveTo(left+(width*0.038), top+(height*0.763), 2.3) # 절전

    pyautogui.mouseDown()
    time.sleep(1)
    pyautogui.mouseUp()

    # time.sleep(3)
    # pyautogui.screenshot(region=(left, top, width, height)).save('jo.png')
    



def play_jo():
    p01_start()
    p02_bok()
    p03_jangbi()












    



    

    """
    arrow_x = max_loc[0] + (width*0.025)         # arrow_image.shape[1] // 2
    arrow_y = max_loc[1] + img_arrow.shape[0] // 2

    pyautogui.moveTo(left + arrow_x, top + arrow_y)

    # OCR 처리 시간 측정 시작
    start_time = time.time()

    # OCR 객체 생성 및 텍스트 추출
    reader = easyocr.Reader(['ko', 'en'], gpu=False)
    results = reader.readtext(screenshot_np)

    # OCR 처리 시간 측정 끝
    end_time = time.time()

    # 소요 시간 출력
    elapsed_time = end_time - start_time
    print(f"OCR 처리에 걸린 시간: {elapsed_time:.2f} 초")

    # 텍스트와 중심 좌표 출력
    print("OCR 텍스트 및 좌표:")
    for detection in results:
        bbox, text, confidence = detection
        top_left = bbox[0]
        bottom_right = bbox[2]
        x = (top_left[0] + bottom_right[0]) // 2
        y = (top_left[1] + bottom_right[1]) // 2
        print(f"{text} [{x}, {y}]")
    """


if __name__ == "__main__":
    # play_jo()
    login_jo()



