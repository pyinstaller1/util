from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QLineEdit, QPushButton, QGroupBox, QVBoxLayout, QHBoxLayout, QComboBox, QCheckBox, QRadioButton, QButtonGroup
from PyQt5.QtGui import QMovie
from PyQt5.QtCore import QSize

from PyQt5.QtCore import Qt

class Robot(QWidget):
    def __init__(self):
        super().__init__()

        # "연계점검 로봇" 라벨 추가
        self.label_robot_title = QLabel('연계점검 로봇 🤖', self)
        self.label_robot_title.setStyleSheet("font-size: 33px; font-weight: bold;")




        self.group_a123 = QGroupBox("건강 ERP", self)
        self.group_a123.setGeometry(15, 70, 220, 225)
        self.group_a123.setStyleSheet("font-size: 12px; font-weight: bold;")

        self.group_a3 = QGroupBox("", self)
        self.group_a3.setGeometry(20, 145, 210, 143)


        self.group_a456 = QGroupBox("징수통합", self)
        self.group_a456.setGeometry(15, 310, 220, 198)
        self.group_a456.setStyleSheet("font-size: 12px; font-weight: bold;")

        self.group_a6 = QGroupBox("", self)
        self.group_a6.setGeometry(20, 385, 210, 116)


        self.group_a789 = QGroupBox("장기요양", self)
        self.group_a789.setGeometry(15, 523, 220, 225)
        self.group_a789.setStyleSheet("font-size: 12px; font-weight: bold;")

        self.group_a9 = QGroupBox("", self)
        self.group_a9.setGeometry(20, 600, 210, 143)

        self.group_a789 = QGroupBox("대외 실시간", self)
        self.group_a789.setGeometry(15, 766, 220, 57)
        self.group_a789.setStyleSheet("font-size: 12px; font-weight: bold;")





        

        # 라벨 생성
        self.label_result_title = QLabel('점검결과', self)  # 점검결과 라벨
        self.label_result_title.setStyleSheet("font-weight: bold;")        
        self.label_input_title = QLabel('정상기준', self)  # 정상기준 라벨
        self.label_input_title.setStyleSheet("font-weight: bold;")
        
        self.label01 = QLabel('오류', self)
        self.label02 = QLabel('처리중', self)
        self.label03_1 = QLabel('AGENT', self)
        self.label03_2 = QLabel('RUNNER', self)
        self.label03_3 = QLabel('채널', self)
        self.label03_4 = QLabel('큐깊이', self)
        self.label03_5 = QLabel('IIP AGENT', self)

        self.label04 = QLabel('오류', self)
        self.label05 = QLabel('처리중', self)
        self.label06_1 = QLabel('AGENT', self)
        self.label06_2 = QLabel('RUNNER', self)
        self.label06_3 = QLabel('채널', self)
        self.label06_4 = QLabel('IIP AGENT', self)

        self.label07 = QLabel('오류', self)
        self.label08 = QLabel('처리중', self)
        self.label09_1 = QLabel('AGENT', self)
        self.label09_2 = QLabel('RUNNER', self)
        self.label09_3 = QLabel('채널', self)
        self.label09_4 = QLabel('큐깊이', self)
        self.label09_5 = QLabel('IIP AGENT', self)
        
        self.label10 = QLabel('오류', self)

     
     





        # 인풋 생성
        self.edit_input01 = QLineEdit(self)
        self.edit_input02 = QLineEdit(self)
        self.edit_input03_1 = QLineEdit(self)
        self.edit_input03_2 = QLineEdit(self)
        self.edit_input03_3 = QLineEdit(self)
        self.edit_input03_4 = QLineEdit(self)
        self.edit_input03_5 = QLineEdit(self)

        self.edit_input04 = QLineEdit(self)
        self.edit_input05 = QLineEdit(self)
        self.edit_input06_1 = QLineEdit(self)
        self.edit_input06_2 = QLineEdit(self)
        self.edit_input06_3 = QLineEdit(self)
        self.edit_input06_4 = QLineEdit(self)

        self.edit_input07 = QLineEdit(self)
        self.edit_input08 = QLineEdit(self)
        self.edit_input09_1 = QLineEdit(self)
        self.edit_input09_2 = QLineEdit(self)
        self.edit_input09_3 = QLineEdit(self)
        self.edit_input09_4 = QLineEdit(self)
        self.edit_input09_5 = QLineEdit(self)

        self.edit_input10 = QLineEdit(self)


        

        # 결과 인풋 생성
        self.edit_result01 = QLineEdit(self)
        self.edit_result02 = QLineEdit(self)
        self.edit_result03_1 = QLineEdit(self)
        self.edit_result03_2 = QLineEdit(self)
        self.edit_result03_3 = QLineEdit(self)
        self.edit_result03_4 = QLineEdit(self)
        self.edit_result03_5 = QLineEdit(self)

        self.edit_result04 = QLineEdit(self)
        self.edit_result05 = QLineEdit(self)
        self.edit_result06_1 = QLineEdit(self)
        self.edit_result06_2 = QLineEdit(self)
        self.edit_result06_3 = QLineEdit(self)
        self.edit_result06_4 = QLineEdit(self)

        self.edit_result07 = QLineEdit(self)
        self.edit_result08 = QLineEdit(self)
        self.edit_result09_1 = QLineEdit(self)
        self.edit_result09_2 = QLineEdit(self)
        self.edit_result09_3 = QLineEdit(self)
        self.edit_result09_4 = QLineEdit(self)
        self.edit_result09_5 = QLineEdit(self)

        self.edit_result10 = QLineEdit(self)





        
        
        self.edit_result01.setReadOnly(True)
        self.edit_result02.setReadOnly(True)
        self.edit_result03_1.setReadOnly(True)
        self.edit_result03_2.setReadOnly(True)
        self.edit_result03_3.setReadOnly(True)
        self.edit_result03_4.setReadOnly(True)
        self.edit_result03_5.setReadOnly(True)
        
        self.edit_result04.setReadOnly(True)
        self.edit_result05.setReadOnly(True)
        self.edit_result06_1.setReadOnly(True)
        self.edit_result06_2.setReadOnly(True)
        self.edit_result06_3.setReadOnly(True)
        self.edit_result06_4.setReadOnly(True)

        self.edit_result07.setReadOnly(True)
        self.edit_result08.setReadOnly(True)
        self.edit_result09_1.setReadOnly(True)
        self.edit_result09_2.setReadOnly(True)
        self.edit_result09_3.setReadOnly(True)
        self.edit_result09_4.setReadOnly(True)
        self.edit_result09_5.setReadOnly(True)        

        self.edit_result10.setReadOnly(True)


        

        # self.edit_result01.setStyleSheet("background-color: #FFFF00; border: 1px solid gray;")  # 셀 내부 배경색을 노란색으로 설정

        
        self.lb_g_01 = QLabel('건', self)
        self.lb_g_02 = QLabel('건', self)
        self.lb_g_03_1 = QLabel('건', self)
        self.lb_g_03_2 = QLabel('건', self)
        self.lb_g_03_3 = QLabel('건', self)
        self.lb_g_03_4 = QLabel('건', self)
        self.lb_g_03_5 = QLabel('건', self)

        self.lb_g_04 = QLabel('건', self)
        self.lb_g_05 = QLabel('건', self)
        self.lb_g_06_1 = QLabel('건', self)
        self.lb_g_06_2 = QLabel('건', self)
        self.lb_g_06_3 = QLabel('건', self)
        self.lb_g_06_4 = QLabel('건', self)

        self.lb_g_07 = QLabel('건', self)
        self.lb_g_08 = QLabel('건', self)
        self.lb_g_09_1 = QLabel('건', self)
        self.lb_g_09_2 = QLabel('건', self)
        self.lb_g_09_3 = QLabel('건', self)
        self.lb_g_09_4 = QLabel('건', self)
        self.lb_g_09_5 = QLabel('건', self)

        self.lb_g_10 = QLabel('건', self)


        

        self.lb_result_01 = QLabel('정상', self)
        self.lb_result_02 = QLabel('정상', self)
        self.lb_result_03 = QLabel('정상', self)

        self.lb_result_04 = QLabel('정상', self)
        self.lb_result_05 = QLabel('정상', self)
        self.lb_result_06 = QLabel('정상', self)

        self.lb_result_07 = QLabel('정상', self)
        self.lb_result_08 = QLabel('정상', self)
        self.lb_result_09 = QLabel('정상', self)

        self.lb_result_10 = QLabel('정상', self)        


        # 인풋 설정
        for edit_field in [self.edit_input01, self.edit_input02, self.edit_input03_1, self.edit_input03_2, self.edit_input03_3, self.edit_input03_4, self.edit_input03_5,
                           self.edit_input04, self.edit_input05, self.edit_input06_1, self.edit_input06_2, self.edit_input06_3, self.edit_input06_4,
                           self.edit_input07, self.edit_input08, self.edit_input09_1, self.edit_input09_2, self.edit_input09_3, self.edit_input09_4, self.edit_input09_5, self.edit_input10]:
            edit_field.setFixedWidth(50)  # 너비 고정
            edit_field.setFixedHeight(25)  # 높이 고정
            edit_field.setAlignment(Qt.AlignRight)  # 오른쪽 정렬
            edit_field.setStyleSheet("font-size: 16px;")  # 글자 크기 16px로 설정
            edit_field.textChanged.connect(self.add_comma)

        # 결과 인풋 설정
        for edit_field in [self.edit_result01, self.edit_result02, self.edit_result03_1, self.edit_result03_2, self.edit_result03_3, self.edit_result03_4, self.edit_result03_5,
                           self.edit_result04, self.edit_result05, self.edit_result06_1, self.edit_result06_2, self.edit_result06_3, self.edit_result06_4,
                           self.edit_result07, self.edit_result08, self.edit_result09_1, self.edit_result09_2, self.edit_result09_3, self.edit_result09_4, self.edit_result09_5, self.edit_result10]:
            edit_field.setFixedWidth(50)  # 너비 고정
            edit_field.setFixedHeight(25)  # 높이 고정
            edit_field.setAlignment(Qt.AlignRight)  # 오른쪽 정렬
            edit_field.setStyleSheet("font-size: 16px;")  # 글자 크기 16px로 설정
            edit_field.textChanged.connect(self.add_comma)

        # 슬래시 라벨
        self.slash_label01 = QLabel('/', self)
        self.slash_label02 = QLabel('/', self)
        self.slash_label03_1 = QLabel('/', self)
        self.slash_label03_2 = QLabel('/', self)
        self.slash_label03_3 = QLabel('/', self)
        self.slash_label03_4 = QLabel('/', self)
        self.slash_label03_5 = QLabel('/', self)

        self.slash_label04 = QLabel('/', self)
        self.slash_label05 = QLabel('/', self)
        self.slash_label06_1 = QLabel('/', self)
        self.slash_label06_2 = QLabel('/', self)
        self.slash_label06_3 = QLabel('/', self)
        self.slash_label06_4 = QLabel('/', self)

        self.slash_label07 = QLabel('/', self)
        self.slash_label08 = QLabel('/', self)
        self.slash_label09_1 = QLabel('/', self)
        self.slash_label09_2 = QLabel('/', self)
        self.slash_label09_3 = QLabel('/', self)
        self.slash_label09_4 = QLabel('/', self)
        self.slash_label09_5 = QLabel('/', self)
        
        self.slash_label10 = QLabel('/', self)



        # 슬래시 라벨 크기 23px로 설정
        self.slash_label01.setStyleSheet("font-size: 23px;")
        self.slash_label02.setStyleSheet("font-size: 23px;")
        self.slash_label03_1.setStyleSheet("font-size: 23px;")
        self.slash_label03_2.setStyleSheet("font-size: 23px;")
        self.slash_label03_3.setStyleSheet("font-size: 23px;")
        self.slash_label03_4.setStyleSheet("font-size: 23px;")
        self.slash_label03_5.setStyleSheet("font-size: 23px;")

        self.slash_label04.setStyleSheet("font-size: 23px;")
        self.slash_label05.setStyleSheet("font-size: 23px;")
        self.slash_label06_1.setStyleSheet("font-size: 23px;")
        self.slash_label06_2.setStyleSheet("font-size: 23px;")
        self.slash_label06_3.setStyleSheet("font-size: 23px;")
        self.slash_label06_4.setStyleSheet("font-size: 23px;")

        self.slash_label07.setStyleSheet("font-size: 23px;")
        self.slash_label08.setStyleSheet("font-size: 23px;")
        self.slash_label09_1.setStyleSheet("font-size: 23px;")
        self.slash_label09_2.setStyleSheet("font-size: 23px;")
        self.slash_label09_3.setStyleSheet("font-size: 23px;")
        self.slash_label09_4.setStyleSheet("font-size: 23px;")
        self.slash_label09_5.setStyleSheet("font-size: 23px;")

        self.slash_label10.setStyleSheet("font-size: 23px;")
















        # 레이아웃 설정
        self.setGeometry(300, 100, 538, 838)
        self.setWindowTitle('연계점검 로봇 🤖')  # 타이틀바에 로봇 이모지 추가

        # 위치 설정
        self.label_robot_title.move(10, 3)  # "연계점검 로봇" 라벨 위치

        self.label_result_title.move(90, 55)  # 점검결과 라벨
        self.label_input_title.move(161, 55)  # 정상기준 라벨






        # 건강ERP
        # 01 오류
        self.label01.move(62, 97)
        self.edit_result01.move(90, 90)
        self.slash_label01.move(145, 90)
        self.edit_input01.move(160, 90)
        self.lb_g_01.move(215, 97)
        self.lb_result_01.move(243, 97)
        

        # 02 점검중
        self.label02.move(50, 124)
        self.edit_result02.move(90, 117)
        self.slash_label02.move(145, 117)
        self.edit_input02.move(160, 117)
        self.lb_g_02.move(215, 124)
        self.lb_result_02.move(243, 124)





        # 03_1 AGENT
        self.label03_1.move(43, 156)  # 117 + 25 + 10 = 149
        self.edit_result03_1.move(90, 149)
        self.slash_label03_1.move(145, 149)
        self.edit_input03_1.move(160, 149)
        self.lb_g_03_1.move(215, 156)

        # 03_2 RUNNER
        self.label03_2.move(37, 183)  # 149 + 25 + 2 = 176
        self.edit_result03_2.move(90, 176)
        self.slash_label03_2.move(145, 176)
        self.edit_input03_2.move(160, 176)
        self.lb_g_03_2.move(215, 183)
        

        # 03_3 채널
        self.label03_3.move(62, 210)  # 176 + 25 + 2 = 203
        self.edit_result03_3.move(90, 203)
        self.slash_label03_3.move(145, 203)
        self.edit_input03_3.move(160, 203)
        self.lb_g_03_3.move(215, 210)
        self.lb_result_03.move(243, 210)

        '''
        self.lb_result_03.setText('이상')  # 내용 변경
        self.lb_result_03.setStyleSheet("font-size: 15px; color: blue; font-weight: bold;")  # 파란색, 굵게 설정
        self.lb_result_03.move(243, 209)        
        '''

        # 03_4 큐깊이
        self.label03_4.move(50, 237)  # 203 + 25 + 2 = 230
        self.edit_result03_4.move(90, 230)
        self.slash_label03_4.move(145, 230)
        self.edit_input03_4.move(160, 230)
        self.lb_g_03_4.move(215, 237)
        

        # 03_5 IIP AGENT
        self.label03_5.move(25, 264)  # 230 + 25 + 2 = 257
        self.edit_result03_5.move(90, 257)
        self.slash_label03_5.move(145, 257)
        self.edit_input03_5.move(160, 257)
        self.lb_g_03_5.move(215, 264)







        # 징수통합
        # 04 오류
        self.label04.move(62, 337)       # 징수통합 오류
        self.edit_result04.move(90, 330)
        self.slash_label04.move(145, 330)
        self.edit_input04.move(160, 330)
        self.lb_g_04.move(215, 337)
        self.lb_result_04.move(243, 337)

        # 05 점검중
        self.label05.move(50, 364)
        self.edit_result05.move(90, 357)
        self.slash_label05.move(145, 357)
        self.edit_input05.move(160, 357)
        self.lb_g_05.move(215, 364)
        self.lb_result_05.move(243, 364)


        # 06_1 AGENT
        self.label06_1.move(43, 396)
        self.edit_result06_1.move(90, 389)
        self.slash_label06_1.move(145, 389)
        self.edit_input06_1.move(160, 389)
        self.lb_g_06_1.move(215, 396)

        # 06_2 RUNNER
        self.label06_2.move(37, 423)
        self.edit_result06_2.move(90, 416)
        self.slash_label06_2.move(145, 416)
        self.edit_input06_2.move(160, 416)
        self.lb_g_06_2.move(215, 423)
        

        # 06_3 채널
        self.label06_3.move(62, 450)
        self.edit_result06_3.move(90, 443)
        self.slash_label06_3.move(145, 443)
        self.edit_input06_3.move(160, 443)
        self.lb_g_06_3.move(215, 450)
        self.lb_result_06.move(243, 437)



        # 06_4 IIP AGENT
        self.label06_4.move(25, 477)
        self.edit_result06_4.move(90, 470)
        self.slash_label06_4.move(145, 470)
        self.edit_input06_4.move(160, 470)
        self.lb_g_06_4.move(215, 477)
        




        # 장기요양
        # 07 오류
        self.label07.move(62, 550)       # 장기요양 오류
        self.edit_result07.move(90, 543)
        self.slash_label07.move(145, 543)
        self.edit_input07.move(160, 543)
        self.lb_g_07.move(215, 550)
        self.lb_result_07.move(243, 550)



        # 08 점검중
        self.label08.move(50, 577)
        self.edit_result08.move(90, 570)
        self.slash_label08.move(145, 570)
        self.edit_input08.move(160, 570)
        self.lb_g_08.move(215, 577)
        self.lb_result_08.move(243, 577)






        # 09_1 AGENT
        self.label09_1.move(43, 612)
        self.edit_result09_1.move(90, 605)
        self.slash_label09_1.move(145, 605)
        self.edit_input09_1.move(160, 605)
        self.lb_g_09_1.move(215, 612)

        # 09_2 RUNNER
        self.label09_2.move(37, 639)
        self.edit_result09_2.move(90, 632)
        self.slash_label09_2.move(145, 632)
        self.edit_input09_2.move(160, 632)
        self.lb_g_09_2.move(215, 639)
        

        # 09_3 채널
        self.label09_3.move(62, 666)  # 176 + 25 + 2 = 203
        self.edit_result09_3.move(90, 659)
        self.slash_label09_3.move(145, 659)
        self.edit_input09_3.move(160, 659)
        self.lb_g_09_3.move(215, 666)
        self.lb_result_09.move(243, 666)


        # 09_4 큐깊이
        self.label09_4.move(50, 693)  # 203 + 25 + 2 = 230
        self.edit_result09_4.move(90, 686)
        self.slash_label09_4.move(145, 686)
        self.edit_input09_4.move(160, 686)
        self.lb_g_09_4.move(215, 693)
        

        # 09_5 IIP AGENT
        self.label09_5.move(25, 720)  # 230 + 25 + 2 = 257
        self.edit_result09_5.move(90, 713)
        self.slash_label09_5.move(145, 713)
        self.edit_input09_5.move(160, 713)
        self.lb_g_09_5.move(215, 720)


        # 대외실시간
        # 10 오류
        self.label10.move(62, 793)       # 대외실시간 오류
        self.edit_result10.move(90, 786)
        self.slash_label10.move(145, 786)
        self.edit_input10.move(160, 786)
        self.lb_g_10.move(215, 793)
        self.lb_result_10.move(243, 793)











        self.group_messenger = QGroupBox("메신저 쪽지 보내기", self)   # 메신저 쪽지 보내기
        self.group_messenger.setStyleSheet("font-size: 12px; font-weight: bold;")        
        self.group_messenger.setGeometry(320, 72, 200, 78)

        self.combo = QComboBox(self)
        self.combo.addItems(["직원1", "직원2", "직원3", "직원4", "직원5"])
        self.combo.setFixedSize(100, 25)
        self.combo.currentIndexChanged.connect(self.change_combo)
        self.combo.move(330, 95)

        self.checkbox = QCheckBox("쪽지전송 버튼 안누르기", self)
        self.checkbox.move(330, 125)  # 위치 설정
        self.checkbox.stateChanged.connect(self.check_state)





        self.group_test = QGroupBox("이상 Test", self)   # 이상 Test
        self.group_test.setStyleSheet("font-size: 12px; font-weight: bold;")        
        self.group_test.setGeometry(320, 180, 200, 150)



        self.radio1 = QRadioButton("No Test", self)
        self.radio1.move(330, 205)
        self.radio1.setChecked(True)

        self.radio2 = QRadioButton("연번 1 이상 Test", self)
        self.radio2.move(330, 228)

        self.radio3 = QRadioButton("연번 2, 5, 8 이상 Test", self)
        self.radio3.move(330, 251)

        self.radio4 = QRadioButton("연번 3, 4, 6, 9, 10 이상 Test", self)
        self.radio4.move(330, 274)

        self.radio5 = QRadioButton("전체 이상 Test", self)
        self.radio5.move(330, 297)



        # 버튼 그룹으로 묶기
        self.button_group = QButtonGroup(self)
        self.button_group.addButton(self.radio1)
        self.button_group.addButton(self.radio2)
        self.button_group.addButton(self.radio3)
        self.button_group.addButton(self.radio4)
        self.button_group.addButton(self.radio5)

        # 라디오 버튼 클릭 함수
        self.radio1.clicked.connect(self.change_radio)
        self.radio2.clicked.connect(self.change_radio)
        self.radio3.clicked.connect(self.change_radio)
        self.radio4.clicked.connect(self.change_radio)
        self.radio5.clicked.connect(self.change_radio)





        self.gif_label = QLabel(self)   # 로봇 gif
        self.gif_label.setGeometry(320, 350, 200, 110)
        self.movie = QMovie("a.gif")
        self.movie.setScaledSize(QSize(200, 110))
        self.gif_label.setMovie(self.movie)
        self.movie.start()




        self.btn_now = QPushButton("지금 실행", self)
        self.btn_now.move(320, 538)
        self.btn_now.setFixedSize(200, 100)
        self.btn_now.setStyleSheet("font-size: 38px; font-weight: bold;")        
        self.btn_now.clicked.connect(self.on_btn_now_click)









    # 콤마 추가 함수
    def add_comma(self):
        text = self.sender().text().replace(',', '')  # 콤마 제거
        if text.isdigit():
            formatted_text = '{:,}'.format(int(text))  # 콤마 추가
            self.sender().setText(formatted_text)
        else:
            self.sender().setText('')


    def change_combo(self):
        print(777)
        print(self.combo.currentText())

    def check_state(self):
        if self.checkbox.isChecked():
            print(777)
            print(self.checkbox.isChecked())
        else:
            print(888)
            print(self.checkbox.isChecked())


    def change_radio(self):
        selected_button = self.button_group.checkedButton()
        if selected_button:
            # self.label.setText(f"선택한 직원: {selected_button.text()}")
            print(selected_button.text())

    def on_btn_now_click(self):
        print(777)
        self.edit_input01.setText("1")
        self.lb_result_01.setText("1")
        print(self.edit_input01.text())
        self.lb_result_01.setStyleSheet("color: #2525F5; font-weight: bold;")  # 글자 색상을 파란색으로 설정

        # self.lb_result_01.hide()  # 라벨 숨기기
        # self.lb_result_01.show()  # 라벨 숨기기



if __name__ == '__main__':
    app = QApplication([])
    window = Robot()
    window.show()
    app.exec_()
