import sys
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QCursor, QPen


item_count = 53

class S1ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if not val: return "0"
            try:
                clean_val = str(val).replace(',', '')
                return format(int(float(clean_val)), ",")
            except:
                return val
        return super().data(role)




# [1] 실시간 우측 정렬 및 기호 드로잉 델리게이트 (s1용 통합 버전)
class RightAlignedDelegate(QStyledItemDelegate):
    def __init__(self, parent):
        super().__init__(parent)
        # 생성 시 부모(TableWidget)를 이벤트 필터로 등록 (평소 상태 감시)
        if parent:
            parent.installEventFilter(self)

    def paint(self, painter, option, index):
        # 기존 기호 드로잉 로직 유지
        super().paint(painter, option, index)
        symbol = index.data(Qt.UserRole)
        if symbol:
            painter.save()
            font = painter.font()
            font.setPointSize(8)
            painter.setFont(font)
            painter.setPen(QColor(60, 60, 60))
            rect = option.rect
            painter.drawText(rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, symbol)
            painter.restore()

    def createEditor(self, parent, option, index):
        if not (index.flags() & Qt.ItemIsEditable):
            return None
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        
        # 실시간 콤마 포맷팅 유지
        editor.textChanged.connect(lambda text: self.format_text(editor, text))
        
        # 입력 중(에디터 활성화)일 때 키 감시를 위해 설치
        editor.installEventFilter(self)
        return editor

    def eventFilter(self, obj, event):
        if event.type() == event.KeyPress:
            # 1. 엔터 키: 아래 셀로 이동 (단순 선택)
            if event.key() in [Qt.Key_Return, Qt.Key_Enter]:
                table = self.parent()
                curr = table.currentIndex()
                next_row = curr.row() + 1
                if next_row < table.rowCount():
                    # 데이터를 모델에 저장하기 위해 인덱스 변경
                    next_idx = table.model().index(next_row, curr.column())
                    table.setCurrentIndex(next_idx)
                return True

            # 2. 오른쪽 방향키
            elif event.key() == Qt.Key_Right:
                # 입력창이 아니거나, 커서가 끝일 때 이동
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == len(obj.text()):
                    self.move_focus(forward=True)
                    return True

            # 3. 왼쪽 방향키
            elif event.key() == Qt.Key_Left:
                # 입력창이 아니거나, 커서가 시작일 때 이동
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == 0:
                    self.move_focus(forward=False)
                    return True

        return super().eventFilter(obj, event)

    def move_focus(self, forward=True):
        """좌우 이동 시 인덱스만 변경 (자동 편집 제거)"""
        table = self.parent()
        curr_idx = table.currentIndex()
        next_col = curr_idx.column() + 1 if forward else curr_idx.column() - 1
        
        if 0 <= next_col < table.columnCount():
            next_idx = table.model().index(curr_idx.row(), next_col)
            table.setCurrentIndex(next_idx)

    def format_text(self, editor, text):
        clean = text.replace(',', '')
        if not clean or clean == "-": return
        try:
            formatted = format(int(float(clean)), ",")
            if text != formatted:
                pos = editor.cursorPosition()
                old_len = len(text)
                editor.blockSignals(True)
                editor.setText(formatted)
                editor.setCursorPosition(pos + (len(formatted) - old_len))
                editor.blockSignals(False)
        except: pass

    def setModelData(self, editor, model, index):
        # 콤마 제거 후 숫자 데이터 저장
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)


        
        

class Sheet1Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_sky_blue = QColor(220, 235, 245)
        self.very_light_gray = QColor(252, 252, 252)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        title = QLabel("(2) 인건비 집계를 위한 Template")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)

        self.table = QTableWidget(item_count, 7)
        self.table.setHorizontalHeaderLabels([
            "인건비 항목", "판관비", "영업외비용", "제조원가", "타계정대체", "이익잉여금", "합계"
        ])

        # 델리게이트 설정
        self.delegate = RightAlignedDelegate(self.table)
        for i in range(1, 7):
            self.table.setItemDelegateForColumn(i, self.delegate)

        self.setup_content()
        self.table.itemChanged.connect(self.calculate_s1)
        
        # 스타일 설정
        # self.table.setStyleSheet("QTableWidget { gridline-color: #d0d0d0; }")


        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section { 
                background-color: #f4f4f4; font-weight: bold; border: 0px;
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; border: 0px; 
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: normal; 
            }
            QScrollBar:vertical { background: #f1f1f1; width: 14px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:vertical { background: #888888; min-height: 30px; border-radius: 2px; }
            QScrollBar:horizontal { background: #f1f1f1; height: 14px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:horizontal { background: #888888; min-width: 30px; border-radius: 2px; }
            
        """)


        
        self.table.setColumnWidth(0, 250)
        for i in range(1, 7): self.table.setColumnWidth(i, 110)
        
        layout.addWidget(self.table)

    def setup_content(self):
        self.table.blockSignals(True)
        
        # [수정] 제수당/인상률제외 삭제 -> 통상임금소송/기타제외 추가
        items = [
            "기본급", "인센티브 상여금", "그 외 상여금", "법정수당", # '제수당' 삭제됨
            "해외근무수당", "그 외 제수당", "퇴직급여(명예퇴직금 포함)", 
            "임원 인건비", "비상임이사 인건비", 
            "통상임금소송으로증가",  # [추가]
            "기타제외인건비",       # [추가]
            "기타항목",            # '인상률제외' 위치 근처
            "급료,임금,제수당 소계ⓐ",         # 행 번호는 그대로 12
            "사내근로복지기금출연금", "국민연금사용자부담분", "건강보험사용자부담분",
            "고용보험사용자부담분", "산재보험료사용자부담분", "급식비", "교통보조비",
            "자가운전보조금", "학자보조금", "건강진단비", "선택적복지", "행사비",
            "포상품(비)", "기념품(비)", "격려품(비)", "장기근속관련 비용",
            "육아보조비 및 출산장려금", "자기계발비", "특별근로의 대가", "피복비",
            "경로효친비", "통신비", "축하금/조의금", "기타 항목",
            "복리후생비 소계 ⓑ",              # 37
            "일반 급여 (1)", "  인센티브 상여금", "  순액",     # 38, 39, 40
            "청년인턴 급여 (2)", "  인센티브 상여금", "  순액", # 41, 42, 43
            "무기계약직 급여 (3)", "  인센티브 상여금", "  순액", # 44, 45, 46
            "소계 ⓒ=(1)+(2)+(3)",             # 47
            "인건비 총계 : ⓓ=ⓐ+ⓑ+ⓒ",         # 48
            "인센티브 상여금 ⓔ=ⓔ-1+ⓔ-2",      # 49
            "  - 인센티브 전환금 (ⓔ-1)",       # 50
            "  - 인센티브 추가금 (ⓔ-2)",       # 51
            "인건비 해당금액 : ⓓ-ⓔ"          # 52
        ]

        self.table.setRowCount(len(items))
        self.readonly_rows = [12, 37, 38, 41, 44, 47, 48, 49, 52] # 행 번호 유지

        soft_sky_blue = QColor(235, 245, 252)

        # 기호 매핑 정의 (인덱스: 기호)
        symbol_map = {
            6: "㈀",  # 퇴직급여
            7: "㈁",  # 임원
            8: "㈂",  # 비상임이사
            9: "㈃",  # 통상임금소송(인상률 제외 인건비)
            13: "㈄", # 사내근로복지기금
            14: "㈅", # 국민연금
            15: "㈅", # 건강보험
            16: "㈅", # 고용보험
            17: "㈅",  # 산재보험
            40: "㈆",  # 일반 급여 - 순액
            43: "㈇",  # 청년인턴 급여 - 순액
            46: "㈈",   # 무기계약직 급여 - 순액
 
        }

        multi_symbol_map = {
            48: {1: "(가)", 2: "(나)", 3: "(다)", 4: "(라)", 5: "(마)"},
            52: {1: "(바)", 2: "(사)", 3: "(아)", 4: "(자)", 5: "(차)"}
        }        
        

        '''
        for r, text in enumerate(items):
            # A열 설정
            name_item = QTableWidgetItem(text)
            name_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            
            # 소계/결과 행은 A열도 파란색 적용
            if r in self.readonly_rows:
                name_item.setBackground(soft_sky_blue)
                name_item.setFont(QFont("맑은 고딕", 9, QFont.Bold))
            else:
                # 회색 주석 처리하셨으므로 흰색으로 설정
                name_item.setBackground(Qt.white)
                
            self.table.setItem(r, 0, name_item)

            for c in range(1, 7):
                cell = ThousandSeparatorItem("0")
                cell.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)

                if r in multi_symbol_map and c in multi_symbol_map[r]:
                    cell.setData(Qt.UserRole, multi_symbol_map[r][c])

                if c == 6 and r in symbol_map:
                    cell.setData(Qt.UserRole, symbol_map[r])
                
                # 결과 행 또는 G열(합계) 보호
                if r in self.readonly_rows or c == 6:
                    cell.setBackground(soft_sky_blue)
                    cell.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                else:
                    cell.setBackground(Qt.white)
                    cell.setFlags(Qt.ItemIsEditable | Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                
                self.table.setItem(r, c, cell)

        self.table.blockSignals(False)
        '''





        # enumerate 대신 range(item_count) 사용
        for r in range(item_count):
            # 1. 항목명 결정 (items 리스트 범위를 벗어나면 빈 문자열)
            text = items[r] if r < len(items) else ""
            
            # A열 설정
            name_item = QTableWidgetItem(text)
            name_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            
            # 항목 이름이 있는 행과 없는 행 구분 스타일링
            if r < len(items):
                if r in self.readonly_rows:
                    name_item.setBackground(soft_sky_blue)
                    name_item.setFont(QFont("Malgun Gothic", 9, QFont.Bold))
                else:
                    name_item.setBackground(Qt.white)
            else:
                # 53번 행 이후 (데이터가 없는 여백 행)
                name_item.setBackground(QColor(250, 250, 250)) # 아주 연한 회색 처리
                
            self.table.setItem(r, 0, name_item)

            # 데이터 열(1~6열) 설정
            for c in range(1, 7):
                cell = S1ThousandSeparatorItem("0")
                cell.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)

                # 53번 행까지만 기존 로직 적용
                if r < len(items):
                    # 기존 수식 기호(symbol_map) 로직 유지
                    if 'multi_symbol_map' in locals() and r in multi_symbol_map and c in multi_symbol_map[r]:
                        cell.setData(Qt.UserRole, multi_symbol_map[r][c])
                    if c == 6 and 'symbol_map' in locals() and r in symbol_map:
                        cell.setData(Qt.UserRole, symbol_map[r])
                    
                    # 보호 및 색상 설정
                    if r in self.readonly_rows or c == 6:
                        cell.setBackground(soft_sky_blue)
                        cell.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    else:
                        cell.setBackground(Qt.white)
                        cell.setFlags(Qt.ItemIsEditable | Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                else:
                    # 여백 행 (100행까지의 나머지)
                    cell.setText("") # 숫자 0도 표시 안 함
                    cell.setBackground(QColor(250, 250, 250))
                    cell.setFlags(Qt.NoItemFlags) # 편집/선택 불가
                
                self.table.setItem(r, c, cell)

        self.table.blockSignals(False)





























    def calculate_s1(self, item):
        col = item.column()
        if col == 0 or col == 6: return 
        
        self.table.blockSignals(True)
        try:
            def get_cell(r, c_idx=None):
                target_col = c_idx if c_idx is not None else col
                it = self.table.item(r, target_col)
                if not it or not it.text().strip(): return 0.0
                try: return float(it.text().replace(',', ''))
                except: return 0.0

            def update_cell(r, c, val, formula):
                it = self.table.item(r, c)
                if it:
                    it.setText(format(int(val), ","))
                    # [수정] 엑셀 어디든 붙여넣기 가능하도록 R1C1 수식 저장
                    it.setData(Qt.UserRole + 1, formula)

            # --- [세로 계산: R1C1 상대 참조 적용] ---
            # 12행(소계a): 위로 12칸
            val_a = sum(get_cell(r) for r in range(12))
            update_cell(12, col, val_a, "=SUM(R[-12]C:R[-1]C)")

            # 37행(소계b): 위로 24칸 (13~36행)
            val_b = sum(get_cell(r) for r in range(13, 37))
            update_cell(37, col, val_b, "=SUM(R[-24]C:R[-1]C)")

            # 38, 41, 44행: 각각 바로 아래 1, 2행 합산
            update_cell(38, col, get_cell(39) + get_cell(40), "=R[1]C+R[2]C")
            update_cell(41, col, get_cell(42) + get_cell(43), "=R[1]C+R[2]C")
            update_cell(44, col, get_cell(45) + get_cell(46), "=R[1]C+R[2]C")

            # 47행(소계c): 38, 41, 44행 합산 (상대 거리 계산)
            val_c = get_cell(38) + get_cell(41) + get_cell(44)
            update_cell(47, col, val_c, "=R[-9]C+R[-6]C+R[-3]C")

            # 48행(총계d): a(-36), b(-11), c(-1) 합산
            val_d = val_a + val_b + val_c
            update_cell(48, col, val_d, "=R[-36]C+R[-11]C+R[-1]C")

            # 49행(인센티브e): 아래 1, 2행 합산
            val_e = get_cell(50) + get_cell(51)
            update_cell(49, col, val_e, "=R[1]C+R[2]C")

            # 52행(결과): d(-4) - e(-3)
            val_result = val_d - val_e
            update_cell(52, col, val_result, "=R[-4]C-R[-3]C")

            # --- [가로 합계: G열 업데이트] ---
            for r in range(53):
                row_sum = sum(get_cell(r, c_idx) for c_idx in range(1, 6))
                # G열 기준 왼쪽 5칸(B~F) 합산
                update_cell(r, 6, row_sum, "=SUM(RC[-5]:RC[-1])")

        except Exception as e:
            print(f"S1 Calc Error: {e}")
        finally:
            self.table.blockSignals(False)

            
    def get_data_to_s2(self):
        # 1. (바~차) 데이터: 52행 1~5열
        data_main = []
        for c in range(1, 6):
            it = self.table.item(52, c); val = float(it.text().replace(',', '')) if it and it.text() else 0.0
            data_main.append(val)

        # 2. (ㄱ~ㅁ) 데이터: 6, 7, 8, 9, 13행의 6열(합계열)
        # 6:퇴직급여, 7:임원, 8:비상임, 9:통상임금, 13:복리후생기금
        data_sub = []
        for r in [6, 7, 8, 9, 13]:
            it = self.table.item(r, 6); val = float(it.text().replace(',', '')) if it and it.text() else 0.0
            data_sub.append(val)

        # 3. (ㅂ)들의 합: 14, 15, 16, 17행의 6열 합산 (4대보험)
        sum_b = 0.0
        for r in [14, 15, 16, 17]:
            it = self.table.item(r, 6); sum_b += float(it.text().replace(',', '')) if it and it.text() else 0.0

        # 4. (ㅅ, ㅇ, ㅈ)의 합: 40, 43, 46행의 6열 합산 (급여 순액들)
        sum_s_o_j = 0.0
        for r in [40, 43, 46]:
            it = self.table.item(r, 6); sum_s_o_j += float(it.text().replace(',', '')) if it and it.text() else 0.0

        # 모든 데이터를 하나의 리스트로 병합
        return data_main + data_sub + [sum_s_o_j, sum_b]




    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        
        min_r, max_r = min(r.topRow() for r in selection), max(r.bottomRow() for r in selection)
        min_c, max_c = min(r.leftColumn() for r in selection), max(r.rightColumn() for r in selection)
        lines = []

        for r in range(min_r, max_r + 1):
            row_data = []
            for c in range(min_c, max_c + 1):
                # --- [A. 가로 합계 열 (G열/6번열)] ---
                if c == 6:
                    # 현재 행의 1~5번 열(B~F)을 합산하는 INDEX 수식
                    formula = "=SUM(INDEX($1:$1048576, ROW(), COLUMN()-5):INDEX($1:$1048576, ROW(), COLUMN()-1))"
                    row_data.append(formula)
                
                # --- [B. 세로 소계/총계 행 (readonly_rows)] ---
                elif r in self.readonly_rows:
                    formula = ""
                    if r == 12: # 소계ⓐ (0~11행 합계)
                        formula = "=SUM(INDEX($1:$1048576, ROW()-12, COLUMN()):INDEX($1:$1048576, ROW()-1, COLUMN()))"
                    elif r == 37: # 소계ⓑ (13~36행 합계)
                        formula = "=SUM(INDEX($1:$1048576, ROW()-24, COLUMN()):INDEX($1:$1048576, ROW()-1, COLUMN()))"
                    elif r in [38, 41, 44, 49]: # 바로 아래 2개 행 합산 (급여 순액 등)
                        formula = "=INDEX($1:$1048576, ROW()+1, COLUMN())+INDEX($1:$1048576, ROW()+2, COLUMN())"
                    elif r == 47: # 소계ⓒ (1+2+3 합산)
                        formula = "=INDEX($1:$1048576, ROW()-9, COLUMN())+INDEX($1:$1048576, ROW()-6, COLUMN())+INDEX($1:$1048576, ROW()-3, COLUMN())"
                    elif r == 48: # 총계ⓓ (ⓐ+ⓑ+ⓒ)
                        formula = "=INDEX($1:$1048576, ROW()-36, COLUMN())+INDEX($1:$1048576, ROW()-11, COLUMN())+INDEX($1:$1048576, ROW()-1, COLUMN())"
                    elif r == 52: # 최종 인건비 (ⓓ-ⓔ)
                        formula = "=INDEX($1:$1048576, ROW()-4, COLUMN())-INDEX($1:$1048576, ROW()-3, COLUMN())"
                    
                    row_data.append(formula if formula else "0")

                # --- [C. 일반 데이터 입력 칸] ---
                else:
                    it = self.table.item(r, c)
                    val = it.text().replace(',', '').strip() if it else ""
                    # 엑셀이 숫자로 인식하도록 처리 (부호가 있는 경우 문자열 처리)
                    if val.startswith(('=', '-', '+')) and not any(char.isdigit() for char in val):
                        val = "'" + val
                    row_data.append(val if val else "0")
            
            lines.append("\t".join(row_data))
            
        QApplication.clipboard().setText("\n".join(lines))


    def paste_selection(self):
        text = QApplication.clipboard().text()
        curr = self.table.currentItem()
        if not text or not curr: return
        
        r_s, c_s = curr.row(), curr.column()
        self.table.blockSignals(True)
        
        changed_columns = set() # 데이터가 변경된 열 번호를 저장할 집합
        
        lines = text.splitlines()
        for i, line in enumerate(lines):
            if not line.strip() and i > 0: continue
            
            cells = line.split('\t')
            for j, val in enumerate(cells):
                r, c = r_s + i, c_s + j
                
                if r < self.table.rowCount() and c < self.table.columnCount():
                    # 수정 차단 로직 (제목열, 합계열, 보호행)
                    if c == 0 or c == 6 or r in self.readonly_rows:
                        continue
                    
                    item = self.table.item(r, c)
                    if item and (item.flags() & Qt.ItemIsEditable):
                        clean_val = val.strip().replace(',', '')
                        item.setText(clean_val)
                        changed_columns.add(c) # 수정된 열 번호 기록

        for col_idx in changed_columns:
         # 각 열의 아무 아이템(여기서는 0행)이나 인자로 전달하여 계산 트리거
            self.calculate_s1(self.table.item(0, col_idx))
                        






    def contextMenuEvent(self, event):
        menu = QMenu(self)
        
        # 1. 'Fusion' 스타일을 강제 지정 (윈도우 기본 테마의 간섭을 무시함)
        menu.setStyle(QStyleFactory.create('Fusion'))
        
        # 2. 스타일시트에서 item과 item:selected를 모두 명시
        menu.setStyleSheet("""
            QMenu { background-color: white; border: 1px solid gray; }
            QMenu::item { padding: 5px 25px; color: black; }
            QMenu::item:selected { background-color: #0078d7; color: white; }
        """)
        
        cp = menu.addAction("복사 (Ctrl+C)")
        ps = menu.addAction("붙여넣기 (Ctrl+V)")
        
        # 사용자님이 요청하신 위치 방식 그대로 사용
        action = menu.exec_(QCursor.pos())
        
        if action == cp: 
            self.copy_selection()
        elif action == ps: 
            self.paste_selection()
            

    # --- [3] 엑셀 호환 복사/붙여넣기 및 키 이벤트 (s2 로직 계승) ---
    def keyPressEvent(self, event):
        if event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_C:
            self.copy_selection()
        elif event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_V:
            self.paste_selection()
        elif event.key() in (Qt.Key_Return, Qt.Key_Enter):
            curr_row = self.table.currentRow()
            if curr_row < self.table.rowCount() - 1:
                self.table.setCurrentCell(curr_row + 1, self.table.currentColumn())
        else:
            super().keyPressEvent(event)





# 만약 단독 실행 테스트를 원하시면 아래 코드를 추가하세요.
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Sheet1Page()
    window.resize(1000, 800)
    window.show()
    sys.exit(app.exec_())





















        
