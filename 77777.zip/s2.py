from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt, QRect
from PyQt5.QtGui import QColor, QFont, QCursor, QPen

# [1] 기호 드로잉 델리게이트: ①, (Ⅰ), (Ⅱ), (Ⅲ) 표시
class SymbolDelegate(QStyledItemDelegate):
    def paint(self, painter, option, index):
        # 기존 정렬 및 기본 그리기 유지
        option.displayAlignment = Qt.AlignRight | Qt.AlignVCenter
        super().paint(painter, option, index)
        
        painter.save()
        painter.setPen(QPen(QColor(60, 60, 60)))
        font = painter.font()
        font.setBold(False)
        painter.setFont(font)
        
        row = index.row()
        col = index.column()




        if row == 30 and col == 2:
            painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(갑)")
        if row == 32 and col == 2:
            painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(을)")

        if row == 29 and col == 2:
            painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "①")
        if row == 29 and col == 3:
            painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "②")
        if row == 29 and col == 4:
            painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "③")
        if row == 30 and col == 3:
            painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "④")
        if row == 30 and col == 4:
            painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑤")


        if row == 31 and col == 3:
            painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑥")
        if row == 31 and col == 4:
            painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑦")
        if row == 32 and col == 3:
            painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑧")
        if row == 32 and col == 4:
            painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑨")
        if row == 33 and col == 3:
            painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑩")
        if row == 33 and col == 4:
            painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑪")           

        if row == 34 and col == 2:
            painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑫")

        if row == 35 and col == 3:
            painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑬")
        if row == 35 and col == 4:
            painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑭")
        if row == 36 and col == 3:
            painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑮")
        if row == 36 and col == 4:
            painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑯") 


            
        if row == 37 and col == 2:
            painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑰")
        elif row == 38 and col == 2:
            painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(Ⅰ)")
        elif row == 38 and col == 3:
            painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(Ⅱ)")
        elif row == 40 and col == 3:
            painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(Ⅱ)")
        elif row == 41 and col == 3:
            painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(Ⅲ)")
            
        # --- [2] 새로 요청하신 B열 우측 수식 드로잉 (추가 구간) ---
        # B열(col 1)의 43, 44행 우측에 수식을 그림으로 그립니다.
        if col == 1:
            # 글자 크기를 살짝 줄여서 수식 느낌을 냅니다.
            font.setPointSize(font.pointSize() - 1)
            painter.setFont(font)
            
            if row == 43:
                # 셀 오른쪽 끝에서 5픽셀 띄우고 수식 그리기
                painter.drawText(option.rect.adjusted(0, 0, -5, 0), Qt.AlignRight | Qt.AlignVCenter, "[(Ⅰ)-(Ⅱ)]/(Ⅱ)")
            elif row == 44:
                # 셀 오른쪽 끝에서 5픽셀 띄우고 수식 그리기
                painter.drawText(option.rect.adjusted(0, 0, -5, 0), Qt.AlignRight | Qt.AlignVCenter, "[(Ⅰ)-(Ⅲ)]/(Ⅲ)")
                
        painter.restore()

    def createEditor(self, parent, option, index):
        if index.row() == 37 and index.column() in [3, 4]:
            return None
        # 계산 결과 및 상한액 셀 입력 방지 (38, 40, 41, 43, 44행)
        if index.row() in [38, 40, 41, 43, 44] and index.column() >= 2:
            return None
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        return editor

class ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)

            if val is None or val == "" or val == "n/a":
                return val

            try:
                table = self.tableWidget()
                index = table.indexFromItem(self) if table else None
                row = index.row() if index else -1
                col = index.column() if index else -1

                # 🔹 44행 3열은 항상 빈칸
                if row == 44 and col == 3:
                    return ""

                num = float(val)

                # 🔥 인상률 행 (43, 44)
                if row in (43, 44):
                    if num == 0:
                        return "0.000%"
                    return f"{round(num, 3):.3f}%"

                # 🔥 나머지: 정수 + 천단위 콤마
                return format(int(num), ",")

            except Exception:
                return val

        return super().data(role)





    


class RightAlignedDelegate(QStyledItemDelegate):
    def __init__(self, parent):
        super().__init__(parent)
        # 생성 시 부모(TableWidget)를 이벤트 필터로 등록하여 평소 키 입력 감시
        if parent:
            parent.installEventFilter(self)

    def createEditor(self, parent, option, index):
        # [기존 유지] 특정 셀 편집 방지 로직 (37행 3, 4열)
        if index.row() == 37 and index.column() in [3, 4]: 
            return None
            
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        
        # 실시간 콤마 포맷팅 연결
        editor.textChanged.connect(lambda text: self.format_text(editor, text))
        
        # 입력 중(에디터 활성화)일 때 키 감시용 설치
        editor.installEventFilter(self)
        return editor

    def eventFilter(self, obj, event):
        if event.type() == event.KeyPress:
            # 1. 엔터 키: 아래 셀로 이동 (단순 선택, 데이터 저장 보장)
            if event.key() in [Qt.Key_Return, Qt.Key_Enter]:
                table = self.parent()
                curr = table.currentIndex()
                next_row = curr.row() + 1
                if next_row < table.rowCount():
                    # setCurrentIndex를 호출해야 작성 중인 데이터가 반영됩니다.
                    next_idx = table.model().index(next_row, curr.column())
                    table.setCurrentIndex(next_idx)
                return True

            # 2. 오른쪽 방향키
            elif event.key() == Qt.Key_Right:
                # 입력창이 아니거나(테이블), 커서가 끝일 때 이동
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == len(obj.text()):
                    self.move_focus(forward=True)
                    return True

            # 3. 왼쪽 방향키
            elif event.key() == Qt.Key_Left:
                # 입력창이 아니거나(테이블), 커서가 앞일 때 이동
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == 0:
                    self.move_focus(forward=False)
                    return True

        return super().eventFilter(obj, event)

    def move_focus(self, forward=True):
        """좌우 이동 시 인덱스만 변경 (자동 편집 제거)"""
        table = self.parent()
        curr_idx = table.currentIndex()
        next_col = curr_idx.column() + 1 if forward else curr_idx.column() - 1
        
        if 0 <= next_col < table.columnCount():
            next_idx = table.model().index(curr_idx.row(), next_col)
            table.setCurrentIndex(next_idx)

    def format_text(self, editor, text):
        clean = text.replace(',', '')
        if not clean or clean == "-": return
        try:
            formatted = format(int(float(clean)), ",")
            if text != formatted:
                pos = editor.cursorPosition()
                old_len = len(text)
                editor.blockSignals(True)
                editor.setText(formatted)
                editor.setCursorPosition(pos + (len(formatted) - old_len))
                editor.blockSignals(False)
        except: pass

    def setModelData(self, editor, model, index):
        # 콤마 제거 후 숫자 데이터 저장
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)


        

class Sheet2Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_sky_blue = QColor(220, 235, 245)
        self.target_light_blue = QColor(238, 238, 255)
        self.very_light_gray = QColor(252, 252, 252) 
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)


        title = QLabel("(3) 총인건비 인상률 지표의 점수계산")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)
        
        self.table = QTableWidget(55, 5)
        self.table.setHorizontalHeaderLabels(["구분", "항목명", "2025", "2024", "2023"])
        
        self.right_delegate = RightAlignedDelegate(self.table)
        for i in range(2, 5): 
            self.table.setItemDelegateForColumn(i, self.right_delegate)

        self.symbol_delegate = SymbolDelegate(self.table)
        # 델리게이트 적용 (기호가 그려질 행들)
        for r in [37, 38, 40, 41, 29, 30, 31, 32, 33, 34, 35, 36]:
            self.table.setItemDelegateForRow(r, self.symbol_delegate)

        self.table.setItemDelegateForColumn(1, self.symbol_delegate) 

        self.table.setShowGrid(True)
        self.table.setGridStyle(Qt.SolidLine)


        self.table.verticalHeader().setFixedWidth(25)


        self.table.setStyleSheet("""
            QTableWidget { 
                gridline-color: #d0d0d0; 
                border: 1px solid #d0d0d0; 
            }
            QHeaderView::section {
                background-color: #f4f4f4; 
                padding: 4px;
                border: 0px; 
                border-right: 1px solid #d0d0d0;
                border-bottom: 1px solid #d0d0d0;
                font-weight: bold;
            }
            QScrollBar:vertical {
                background: #f1f1f1;
                width: 16px;
                margin: 0px 0px 0px 0px;
                border: 1px solid #dcdcdc;
            }
            QScrollBar::handle:vertical {
                background: #888888;
                min-height: 30px;
                border-radius: 2px;
            }
            QScrollBar::handle:vertical:hover {
                background: #555555;
            }
            QScrollBar:horizontal {
                background: #f1f1f1;
                height: 16px;
                margin: 0px 0px 0px 0px;
                border: 1px solid #dcdcdc;
            }
            QScrollBar::handle:horizontal {
                background: #888888;
                min-width: 30px;
                border-radius: 2px;
            }
            QScrollBar::handle:horizontal:hover {
                background: #555555;
            }
            QScrollBar::add-line, QScrollBar::sub-line {
                width: 0px;
                height: 0px;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; border: 0px; 
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: normal; /* 번호열 글자 굵게 하지 않음 */
            }  
        """)



        title_font = QFont("맑은 고딕", 9)
        title_font.setBold(True)
        
        for c in range(self.table.columnCount()):
            item = self.table.horizontalHeaderItem(c)
            if item:
                item.setFont(title_font) # 헤더 텍스트 굵게

        
        self.table.verticalHeader().setDefaultSectionSize(26)
        self.table.setColumnWidth(0, 70)  
        self.table.setColumnWidth(1, 460)
        for i in range(2, 5): self.table.setColumnWidth(i, 115)

        self.setup_content()
        
        # [핵심] 테이블 아이템 클릭 시 handle_b_column_click 함수 실행!
        self.table.itemClicked.connect(self.handle_b_column_click)
        self.table.itemChanged.connect(self.calculate_s2)
        layout.addWidget(self.table)










    def setup_content(self):
        self.table.blockSignals(True)
        
        # 1. 테이블 초기화 및 기본 정렬/배경 세팅
        for r in range(self.table.rowCount()):
            for c in range(5):
                item = ThousandSeparatorItem("") if c >= 2 else QTableWidgetItem("")
                self.table.setItem(r, c, item)
                if r in [1, 2, 3, 4, 5, 8, 9, 10, 11, 12, 13, 14, 30, 32] and c == 2:
                    item.setBackground(QColor(255, 255, 225)) # 연한 노란색
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) 
                    item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)            
                if r == 45:
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)                
                if c == 0: item.setTextAlignment(Qt.AlignCenter)
                elif c == 1: 
                    item.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
                    item.setBackground(self.very_light_gray)
                else: 
                    item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                    item.setText("0")

        self.table.item(43, 2).setData(Qt.EditRole, 0.0)
        self.table.item(44, 2).setData(Qt.EditRole, 0.0)
        self.table.item(43, 3).setText("")

        fixed_item = self.table.item(43, 3)
        fixed_item.setText("2.469%")
        fixed_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)



        


        # 2. A열 병합 및 대분류 텍스트
        self.table.setSpan(0, 0, 30, 1) 
        self.table.item(0, 0).setText("실집행액 기준 총인건비 발생액 산출")
        self.table.setSpan(30, 0, 9, 1)
        self.table.item(30, 0).setText("전년대비 조정된 총인건비 발생액 산출")
        self.table.setSpan(39, 0, 6, 1)
        self.table.item(39, 0).setText("당해연도 총인건비 인상률 계산")

        for r in [0, 30, 39]:
            it = self.table.item(r, 0)
            if it:
                it.setBackground(self.base_sky_blue)
                it.setFont(QFont("맑은 고딕", 8, QFont.Bold))

        # 3. B열 항목명 정의
        b_dict = {
            0: "1. 인센티브 상여금을 제외한 인건비 총액",
            1: "  a. 판관비로 처리한 인건비 <주1>",
            2: "  b. 영업외비용으로 처리한 인건비 <주2>",
            3: "  c. 제조원가로 처리한 인건비 <주3>",
            4: "  d. 타계정대체로 처리한 인건비 <주4>",
            5: "  e. 이익잉여금의 증감으로 처리한 인건비 <주5>",
            6: "▶ 소계 : (A)=a+b+c+d+e",
            7: "2. 총인건비 인상률 계산에서 제외(조정)되는 인건비",
            8: "  f. 퇴직급여(명예퇴직금 포함) <주6>",
            9: "  g. 임원 인건비<주7>",
            10: "  h. 비상임이사 인건비<주8>",
            11: "  i. 인상률 제외 인건비<주9>",
            12: "  j. 사내근로복지기금출연금<주10>",
            13: "  k. 잡급 및 무기계약직 인건비 <주11>",
            14: "  l. 공적보험 사용자부담분<주12>",
            15: "  m. 연월차수당 등 조정(㉠-㉡+㉢)<주13>",
            16: "    - 연월차수당 등 발생액(㉠)",
            17: "    - 연월차수당 등 지급액(㉡)",
            18: "    - 종업원 저리 대여금 이자 관련 인건비(㉢)",
            19: "  n. 저리·무상대여 이익<주14>",
            20: "  o. 지방이전 관련 직접 인건비<주15>",
            21: "  p. 법령에 따른 특수건강진단비<주16>",
            22: "  q. 해외근무수당<주17>",
            23: "  r. 직무발명보상금<주18>",
            24: "  s. 자녀수당 및 출산축하금<주19>",
            25: "  t. 야간간호특별수당<주20>",
            26: "  u. 비상진료체계 운영에 따른 특별수당 등<주21>",
            27: "  v. 통상임금 판례 영향 법정수당 증가분 <주22>",
            28: "▶ 소계 : (B)=f+g+h+i+j+k+l+m-n+o+p+q+r+s+t+u+v",
            29: "3. 실집행액기준 총인건비 발생액 (C)=(A)-(B)",
            30: "4. 연도별 증원소요 인건비의 영향을 제거하기 위한 인건비의 조정(D) <주23>",
            31: "5. 별도직군 승진시기 차이에 따른 인건비 효과 조정(E) <주24>",
            32: "6. 초임직급 정원 변동에 따른 인건비 효과 조정(F) <주25>",
            33: "7. 정년이후 재고용을 전제로 전환된 정원외인력의 인건비 효과 조정(G) <주26>",
            34: "8. 생산량증가로 인하여 ’25년도’에 추가로 지급된 인건비의 영향 제거(H) <주27>",
            35: "9. 최저임금 지급 직원에 대한 인건비 효과 조정(I) <주28>",
            36: "10. 파업 등에 따른 인건비 효과 조정(J) <주29>",
            37: "11. 통상임금 판단기준 변경 판례의 영향으로 인한 법정수당 증가분(2025년 귀속분) (K) <주30>",
            38: "12. 총인건비 인상률 계산대상 총인건비 발생액\n  = (C)+(D)+(E)-(F)-(G)-(H)+(I)+(J)-(K) <주31>",
            39: "13. 총인건비 인상률 가이드라인에 따른 총인건비 상한액 <주32>",
            40: "  (1) ’24년도 총인건비 인상률 가이드라인을 준수한 경우",
            41: "  (2) ’24년도 총인건비 인상률 가이드라인을 준수하지 않은 경우",
            42: "14. 총인건비 인상률 산출(’25년도 총인건비 인상률 가이드라인 = 3.0%) <주33>",
            43: "  (1) ’24년도 총인건비 인상률 가이드라인을 준수한 경우",
            44: "  (2) ’24년도 총인건비 인상률 가이드라인을 준수하지 않은 경우"
        }

        # 4. B열 항목 적용 및 읽기전용 설정
        for r, text in b_dict.items():
            it = self.table.item(r, 1)
            if it:
                it.setText(text)
                # B열은 클릭 시 안내창 팝업을 위해 수정 불가(읽기전용)로 설정
                it.setFlags(it.flags() & ~Qt.ItemIsEditable)

                # 제목줄 배경색 및 폰트 설정
                if r in [0, 6, 7, 15, 28, 29, 38, 39, 42]: 
                    bg = self.base_sky_blue if r in [0, 7, 29, 38, 39, 42] else self.target_light_blue
                    it.setBackground(bg)
                    it.setFont(QFont("맑은 고딕", 9, QFont.Bold))
                    
                    for c in range(2, 5):
                        target_item = self.table.item(r, c)
                        if target_item:
                            target_item.setBackground(bg)
                            # [핵심] 15번도 이제 여기서 직접 입력을 막습니다.
                            if r != 39 and r != 42:
                                target_item.setFlags(target_item.flags() & ~Qt.ItemIsEditable)
     

        # 5. n/a 처리 및 기타 행 설정
        # 막아야 할 (행, 열) 좌표들을 리스트에 담습니다.
        na_list = [
            (37, 3), (37, 4), (27, 3), (27, 4), (34, 3), (34, 4), 
            (39, 2), (40, 2), (41, 2), (39, 3), (39, 4), (40, 4), (41, 4),
            (42, 2), (42, 3), (42, 4), (43, 4), (44, 4)
        ]

        for target_r, target_c in na_list:
            na_item = self.table.item(target_r, target_c)
            if na_item:
                na_item.setText("n/a")
                na_item.setBackground(self.base_sky_blue)
                na_item.setFlags(na_item.flags() & ~Qt.ItemIsEditable)
                na_item.setTextAlignment(Qt.AlignCenter)

        target_rows = [40, 41, 42, 43, 44]
        
        for r in target_rows:
            # 2번 열(C열)부터 4번 열(E열)까지 모두 파란색 및 입력 차단
            for c in range(1, 5):
                item = self.table.item(r, c)
                if item:
                    item.setBackground(self.base_sky_blue) # 파란색 배경
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable) # 입력 막기



        self.table.setRowHeight(38, 48)
        self.table.setRowCount(47)

        # 6. 안내 문구 (인덱스 46)
        self.table.setSpan(45, 0, 1, 5)
        self.table.setRowHeight(45, 10) 


        footer_text = (
            "’25년도(Ⅰ) = ①－⑫－⑰\n"
            "‘24년도 총인건비 인상률 준수기관(Ⅱ) = ②+④+⑥-⑧-⑩+⑬+⑮\n"
            "‘24년도 총인건비 인상률 위반기관(Ⅲ) = {(③+⑤+⑦-⑨-⑪+⑭+⑯)×(1+0.025)}+④+⑥-⑧-⑩+⑬+⑮\n\n"
            "※ 총인건비 인상률 산출계산 방법 <주33>\n"
            "(1) ‘24년도 총인건비인상률 준수기관 = [(Ⅰ)-(Ⅱ)]/(Ⅱ)\n"
            "(2) ‘24년도 총인건비인상률 위반기관 = [(Ⅰ)-(Ⅲ)]/(Ⅲ)\n\n"
            "※ 2024년 미위반기관은 2025년과 2024년만 기재\n\n"
            
        )
        it_footer = QTableWidgetItem(footer_text)
        it_footer.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 수정 불가
        it_footer.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.table.setItem(46, 0, it_footer)
        self.table.setSpan(46, 0, 1, 5)
        self.table.setRowHeight(46, 180)

        self.table.blockSignals(False)


    def handle_b_column_click(self, item):
        if item.column() != 1: return
            
        row_index = self.table.row(item)
        full_text = item.text().strip()

        descriptions = [
            "",
            "<b>&lt;주1&gt;</b><br> 인건비 집계를 위한 template상의 (바)에 기입된 금액을 옮겨 적음.",
            "<b>&lt;주2&gt;</b><br> 인건비 집계를 위한 template상의 (사)에 기입된 금액을 옮겨 적음.",
            "<b>&lt;주3&gt;</b><br> 인건비 집계를 위한 template상의 (아)에 기입된 금액을 옮겨 적음.",
            "<b>&lt;주4&gt;</b><br> 인건비 집계를 위한 template상의 (자)에 기입된 금액을 옮겨 적음.",
            "<b>&lt;주5&gt;</b><br> 인건비 집계를 위한 template상의 (차)에 기입된 금액을 옮겨 적음.",
            "",
            "",
            "<b>&lt;주6&gt;</b><br> 인건비 집계를 위한 template상의 (ㄱ)에 기입된 금액을 옮겨 적음.",
            "<b>&lt;주7&gt;</b><br> 인건비 집계를 위한 template상의 (ㄴ)에 기입된 금액을 옮겨 적음.",
            "<b>&lt;주8&gt;</b><br> 인건비 집계를 위한 template상의 (ㄷ)에 기입된 금액을 옮겨 적음.",
            "<b>&lt;주9&gt;</b><br> 인건비 집계를 위한 template상의 (ㄹ)에 기입된 금액을 옮겨 적음.",
            "<b>&lt;주10&gt;</b><br> 인건비 집계를 위한 template상의 (ㅁ)에 기입된 금액을 옮겨 적음.",
            "<b>&lt;주11&gt;</b><br> 인건비 집계를 위한 template상의 (ㅅ)과 (ㅇ) 및 (ㅈ)를 합한 금액을 적음. 잡급 및 무기계약직에 대한 인센티브상여금은 이미 고려되었으므로 이중계산 방지 유의",
            "<b>&lt;주12&gt;</b><br> 인건비 집계를 위한 template상의 (ㅂ)에 기입된 공적보험(국민연금, 건강보험, 고용보험 및 산재보험료 사용자 부담분) 금액을 옮겨 적음.",
            "<b>&lt;주13&gt;</b><br> K-IFRS를 적용하는 공공기관의 경우 종업원급여 추정치(연월차수당, 장기근속수당 등)를 현금기준으로 조정하기 위한 것임. 연월차수당 등 발생액은 K-IFRS에 의해 종업원급여 추정치(연월차수당 , 장기근속수당 등)를 인건비로 계상한 것을 의미하며, 연월차수당 등 지급액은 실제 해당연도에 지급한 금액을 의미함. 기타 이와 유사한 성격의 인건비(예, 성과상여금 등의 추정치를 발생주의로 계상한 금액)가 있을 경우 동일하게 적용함. 종업원 저리대여금 이자 관련 인건비는 K-IFRS에 의한 저리대여금 이자를 인건비로 회계처리한 것을 조정하기 위한 것임.",
            "",
            "",
            "",
            "<b>&lt;주14&gt;</b><br> 저리 또는 무상으로 사내대출을 받음으로써 「소득세법」상 근로소득에 해당하는 이익",
            "<b>&lt;주15&gt;</b><br> 「혁신도시 조성 및 발전에 관한 특별법」에 따른 지방이전 기관의 경우, 지방이전으로 인해 직접적으로 소요된 경비(이주수당 등)를 지방이전 후 2년간 제외함. 지방이전 관련 직접 인건비를 기재하는 기관은 이전시점 및 이전에 따른 인건비 항목, 인건비 제외기간을 별도 제시",
            "<b>&lt;주16&gt;</b><br> 「산업안전보건법」에 따라 특수건강진단대상업무에 종사하는 근로자에게 실시하는 특수건강진단비 금액을 기입함.",
            "<b>&lt;주17&gt;</b><br> 공무원 수준 이내에서 집행한 해외근무수당 금액을 기입함.",
            "<b>&lt;주18&gt;</b><br> ｢발명진흥법｣ 제15조에 따른 직무발명보상금 금액을 기입함.",
            "<b>&lt;주19&gt;</b><br> 공무원 수준 내 지급되는 자녀수당 및 출산축하금을 기입함. ",
            "<b>&lt;주20&gt;</b><br>「간호인력 야간근무 가이드라인」을 준수하면서 야간간호료 수가 내 지급되는 야간간호특별수당을 기입함.",
            "<b>&lt;주21&gt;</b><br> 비상진료체계 종료 전까지의 공공의료기관 비상진료체계 운영에 기여한 정도를 감안한 내부기준에 따라 지급한 특별수당 등을 기입함.",
            "<b>&lt;주22&gt;</b><br> 2025년도 예산운용지침상 공공기관이 당사자인 통상임금 소송 결과가 있거나 통상임금 여부를 권한있는 행정기관이 확인한 경우, 그로 인한 법정수당 증가분 중 2024년 귀속분을 기재",
            "",
            "",            
            "<b>&lt;주23&gt;</b><br> 증원소요 인건비 계산 template(3-1) 상의 (갑) 금액을 옮겨 적으며, 감원이 있었던 경우에는 그 수치가 음수가 됨.<br&gt;</b><br><br&gt;</b><br>(1) ’25년도 증원소요인건비 조정액(④) : ’25년도 증원소요인건비(전 기관 기재)<br&gt;</b><br>(2) ’24년도 증원소요인건비 조정액(⑤) : ’24년도 증원소요인건비<br&gt;</b><br>(’24년도 총인건비 인상률 위반기관만 기재)",
            "<b>&lt;주24&gt;</b><br> (3-5)의 “라. 별도직군 승진시기에 따른 인건비효과” (갑)에 기입된 금액을 옮겨 적음.",
            "<b>&lt;주25&gt;</b><br> (3-6)의 “나. 초임직급 정원변동에 따른 인건비 효과” (을)에 기입된 금액을 옮겨 적음.",
            "<b>&lt;주26&gt;</b><br> 정년 이후 재고용을 전제로 임금피크제를 적용하면서 정년도래 전에 정원외인력으로 전환한 경우 전환 이후 해당 정원외인력에게 지급된 인건비를 기재함.",
            "<b>&lt;주27&gt;</b><br> 제조업을 영위하는 공기업에 있어서 정부시책에 의하여 당기의 생산량이 전기에 비하여 증가한 이유로 임직원에게 당기에 추가로 지급된 인건비를 의미함. 단, 비교시 인건비가 감소한 경우에는 그 감소액을 음수로 표시함. ",
            "<b>&lt;주28&gt;</b><br> 최저임금 대상인 직원에게 지급한 당년도 실제 인건비에서 인상률 가이드라인만큼 인건비를 인상할 경우의 지급 추정액을 차감한 금액을 기재함.",
            "<b>&lt;주29&gt;</b><br> 합법적인 파업 등에 따라 전년도에 지급되지 않은 인건비 감소액(양수)과 이로 인해 불가피하게 대체근무 등으로 추가 지급된 전년도 인건비 증가액(음수)을 상계한 금액을 기재함. 전년도 미집행액을 한도로 하되, 미집행액은 과거 3개년 평균 총인건비 실집행률을 고려한 범위 내의 금액으로 함.",
            "<b>&lt;주30&gt;</b><br> 2025년도 예산운용지침상 공공기관이 당사자인 통상임금 소송 결과가 있거나 통상임금 여부를 권한있는 행정기관이 확인한 경우, 그로 인한 법정수당 증가분 중 2025년 귀속분을 기재",
            "<b>&lt;주31&gt;</b><br> 총인건비 인상률 계산대상 총인건비 발생액 산출방법<br&gt;</b><br> - ’25년도(Ⅰ) = ①－⑫－⑰<br&gt;</b><br> - ‘24년도 총인건비 인상률 준수기관(Ⅱ) = ②+④+⑥-⑧-⑩+⑬+⑮<br&gt;</b><br>",
            "<b>&lt;주32&gt;</b><br> 전기 ‘총인건비 인상률 가이드라인에 따른 총인건비 상한액’의 산출<br&gt;</b><br> (1) ‘24년도 총인건비 인상률 준수기관: ②+④+⑥-⑧-⑩+⑬+⑮<br&gt;</b><br> (2) ‘24년도 총인건비 인상률 위반기관<br&gt;</b><br>  ㉠ ’23년까지 인상률을 준수한 기관: {(③+⑤+⑦-⑨-⑪+⑭+⑯)×(1+0.025)}+④+⑥-⑧-⑩+⑬+⑮<br&gt;</b><br> ㉡ `23년 이전부터 인상률을 위반한 기관 : 총인건비 인상률을 위반하지 아니한 가장 최근연도를 기준으로, 그 이후연도의 총인건비 인상률 가이드라인을 준수하였을 경우를 가정하여 총인건비 상한액을 계산함",
            "",
            "",
            "<b>&lt;주33&gt;</b><br> ‘25년도 총인건비 인상률 가이드라인은 3.0%임(다만, 2023년도 정규직(무기계약직 포함) 1인당 평균임금이 해당 산업평균의 90%이하이며 공공기관 평균의 60%이하인 기관은 4.0%, 해당 산업평균의 90%이하이며 공공기관 평균의 70%이하인 기관은 3.5%, 해당 산업평균의 110%이상이며 공공기관 평균의 120%이상에 해당하는 기관은 2.5%임). 2025년 중 총인건비 인상률(2.5~4.0% 중 기관별로 적용되는 총인건비 인상률) 이외에 베이스 조정이 있는 기관은 동 규모를 고려한다.<br&gt;</b><br><br&gt;</b><br>※ 총인건비 인상률 산출계산 방법<br&gt;</b><br> (1) ‘24년도 총인건비인상률 준수기관 = [(Ⅰ)-(Ⅱ)]/(Ⅱ)<br&gt;</b><br> (2) ‘24년도 총인건비인상률 위반기관 = [(Ⅰ)-(Ⅲ)]/(Ⅲ) ",

        ]


        if row_index < len(descriptions) and descriptions[row_index]:
            # [수정] 아래 replace 줄을 완전히 삭제하거나 아래처럼 변수만 넘깁니다.
            user_typing = descriptions[row_index] 

            from PyQt5.QtWidgets import QMessageBox
            msg = QMessageBox(self)
            msg.setWindowTitle("상세 항목 안내")
            
            # 여기서 user_typing에 포함된 <b>와 <br>이 HTML로 작동하게 됩니다.
            msg.setText(f"<b>[{full_text}]</b><br><br>{user_typing}")
            msg.setStandardButtons(QMessageBox.Ok)
            msg.exec_()



    def calculate_s2(self, item):
        col = item.column()
        if col < 2: return  

        self.table.blockSignals(True)
        try:
            def gv(r, c=None):   # ["n/a", "-", ""] 이면 0.0을 반환
                target_col = c if c is not None else col
                it = self.table.item(r, target_col)
                if not it: 
                    return 0.0
                
                txt = it.text().strip().replace(',', '')
                if not txt or txt in ["n/a", "-", ""]:
                    return 0.0
                try:
                    return float(txt)
                except:
                    return 0.0


            # 소계(A) = sum(1, 5)
            sum_a = sum(gv(r) for r in range(1, 6))
            self.table.item(0, col).setText(format(int(sum_a), ","))   # 0번 행에 소계(A) 입력
            self.table.item(6, col).setText(format(int(sum_a), ","))   # 6번 행에 소계(A) 입력


            # 연월차 15 = 16 - 17 + 18
            val_m = gv(16) - gv(17) + gv(18)
            self.table.item(15, col).setText(format(int(val_m), ","))


            # 소계(B) = sum(8, 27) - (16 - 17 + 18)
            pure_data_sum = sum(gv(r) for r in range(8, 28) if r not in [15, 16, 17, 18])
            sum_b = pure_data_sum + val_m
            
            self.table.item(7, col).setText(format(int(sum_b), ","))    #  7번 행에 소계(B) 입력
            self.table.item(28, col).setText(format(int(sum_b), ","))   # 28번 행에 소계(B) 입력


            # (C) = (A) - (B)
            sum_c = sum_a - sum_b
            self.table.item(29, col).setText(format(int(sum_c), ","))



            # (I), (II)
            v_i =  sum_c - gv(34, 2) - gv(37, 2)
            v_ii = gv(29, 3) + gv(30, 3) + gv(31, 3) - gv(32, 3) - gv(33, 3) + gv(35, 3) + gv(36, 3)
            v_ii_2023 = gv(29, 4) + gv(30, 4) + gv(31, 4) - gv(32, 4) - gv(33, 4) + gv(35, 4) + gv(36, 4)

            self.table.item(38, 2).setText(format(int(v_i), ","))   # (I)
            self.table.item(38, 3).setText(format(int(v_ii), ","))   # (II)
            self.table.item(38, 4).setText(format(int(v_ii_2023), ","))   # (II) 2023
            self.table.item(40, 3).setText(format(int(v_ii), ","))


            # (III)            
            v_iii = ((gv(29, 4) + gv(30, 4) + gv(31, 4) - gv(32, 4) - gv(33, 4) + gv(35, 4) + gv(36, 4)) * (1 + 0.025)) + gv(30, 3) + gv(31, 3) - gv(32, 3) - gv(33, 3) + gv(35, 3) + gv(36, 3)
            self.table.item(41, 3).setText(format(int(v_iii), ","))





            # 14. 총인건비 인성률 산출
            if not v_ii:
                self.table.item(43, 2).setText('0.000%')
            else:
                self.table.item(43, 2).setText(format((((v_i - v_ii)/v_ii)*100), ",.3f").rstrip('.') + '%')
            self.table.item(43, 3).setText('2.469%')

            if not v_iii:
                self.table.item(44, 2).setText('0.000%')
            else:
                self.table.item(44, 2).setText(format((((v_i - v_iii)/v_iii)*100), ",.3f").rstrip('.') + '%')
            self.table.item(44, 3).setText('')






        except Exception as e:
            print(f"!!! 계산 에러 !!!: {e}")
        finally:
            self.table.blockSignals(False)
            self.table.viewport().update()





    def sync_from_s1(self, data_list):
        """S1에서 받은 리스트를 지정된 행 위치에 매핑하여 주입"""
        if not data_list or len(data_list) < 12: return
        
        self.table.blockSignals(True)
        try:
            # 1. 주1 ~ 주5 (index 0~4) -> 1 ~ 5행
            for i in range(0, 5):
                item = self.table.item(i + 1, 2)
                if item: item.setText(format(int(round(data_list[i])), ","))

            # 2. 주6 ~ 주10 (index 5~9) -> 8 ~ 12행
            # i가 5일 때 8행, 6일 때 9행... (i + 3)
            for i in range(5, 10):
                item = self.table.item(i + 3, 2)
                if item: item.setText(format(int(round(data_list[i])), ","))

            # 3. 주11 (index 10) -> 14행
            item_11 = self.table.item(14, 2)
            if item_11: item_11.setText(format(int(round(data_list[10])), ","))

            # 4. 주12 (index 11) -> 13행
            item_12 = self.table.item(13, 2)
            if item_12: item_12.setText(format(int(round(data_list[11])), ","))

        finally:
            self.table.blockSignals(False)
            
        # Sheet2 전체 계산 로직 호출 (기준 셀 전달)
        self.calculate_s2(self.table.item(1, 2))





            

    def sync_from_s3(self, gab_value):
        """MainWindow를 통해 S3의 (갑) 데이터를 주입받음"""
        self.table.blockSignals(True)
        try:
            # gab_value가 숫자형태로 들어온다고 가정 (str이면 float 변환)
            val = float(str(gab_value).replace(',', '')) if gab_value else 0.0
            
            # Sheet2의 30행(D.연도별 증원소요...), 2열(2025년 열)
            item = self.table.item(30, 2)
            if item:
                item.setText(format(int(round(val)), ",d"))
                
        finally:
            self.table.blockSignals(False)
            
            # 값이 바뀌었으므로 Sheet2 전체 계산(calculate_s2) 트리거
            trigger_item = self.table.item(30, 2)
            if trigger_item:
                # 상위 클래스(Sheet2)의 계산 로직을 호출하여 인상률 등에 즉각 반영
                self.calculate_s2(trigger_item)


    def sync_eul_from_s10(self, eul_value):
        """
        Sheet10에서 계산된 (을) 값을 Sheet2의 32행 2열(2025년)에 주입
        """
        if eul_value is None:
            return

        self.table.blockSignals(True) # 주입 중 무한 루프 방지
        
        try:
            target_row = 32  # (을) 그림이 있는 32행
            target_col = 2   # 2025년 데이터 열
            
            item = self.table.item(target_row, target_col)
            if not item:
                item = ThousandSeparatorItem("0")
                self.table.setItem(target_row, target_col, item)
            
            # 숫자 변환 및 반올림 처리
            try:
                # 콤마 제거 후 실수 변환 -> 반올림 -> 정수형 콤마 포맷
                numeric_val = float(str(eul_value).replace(',', ''))
                formatted_val = format(int(round(numeric_val)), ",")
                item.setText(formatted_val)
            except (ValueError, TypeError):
                item.setText("0")

            item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            
        except Exception as e:
            print(f"Sheet2 데이터 주입 실패: {e}")
            
        finally:
            self.table.blockSignals(False)
            
        # [핵심] 값이 주입된 후 Sheet2의 전체 계산 로직을 호출하여 인상률 등에 즉시 반영
        self.calculate_s2(self.table.item(32, 2))


    





    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        
        min_r, max_r = min(r.topRow() for r in selection), max(r.bottomRow() for r in selection)
        min_c, max_c = min(r.leftColumn() for r in selection), max(r.rightColumn() for r in selection)

        max_r = max_r - 2
        
        lines = []
        if min_r == 0:
            headers = [self.table.horizontalHeaderItem(c).text() for c in range(min_c, max_c + 1)]
            lines.append("\t".join(headers))

        for r in range(min_r, max_r + 1):
            row_data = []
            for c in range(min_c, max_c + 1):
                # INDEX($1:$1048576, ROW() + offset, COLUMN() + offset) 방식 사용
                # r_off: 대상 행과 현재 행의 차이 / c_off: 대상 열과 현재 열의 차이
                def idx(target_r, target_c=None):
                    r_diff = target_r - r 
                    target_col_idx = target_c if target_c is not None else c
                    c_diff = target_col_idx - c
                    return f"INDEX($1:$1048576,ROW()+({r_diff}),COLUMN()+({c_diff}))"

                val = ""
                # --- [A. n/a 처리] ---
                na_list = [(27, 3), (27, 4), (34, 3), (34, 4), (37, 3), (37, 4),
                           (39, 2), (39, 3), (39, 4), (40, 2), (40, 4), (41, 2), (41, 4),
                           (42, 2), (42, 3), (42, 4), (43, 4), (44, 4)]
                
                if (r, c) in na_list:
                    val = "n/a"
                
                # --- [B. 수식 적용 구역 (INDEX 방식)] ---
                elif c >= 2:
                    # 1. 항목 소계 (0, 6행) -> 1~5행 합계
                    if r == 0 or r == 6:
                        val = f"=SUM({idx(1)}:{idx(5)})"
                    
                    # 15번 (m) 소계 (15행) -> 16-17+18행
                    elif r == 15:
                        val = f"={idx(16)}-{idx(17)}+{idx(18)}"
                    
                    # 2. 항목 및 B 소계 (7, 28행)
                    elif r == 7 or r == 28:
                        val = f"=SUM({idx(8)}:{idx(14)})+{idx(15)}+SUM({idx(19)}:{idx(27)})"
                    
                    # (C) 발생액 (29행) -> 6행 - 28행
                    elif r == 29:
                        val = f"={idx(6)}-{idx(28)}"
                    
                    # 총인건비 발생액 (38행)
                    elif r == 38:
                        if c == 2: # 2025년 (본인 열 기준 계산)
                            val = f"={idx(29)}-{idx(34)}-{idx(37)}"
                        else:      # 2024, 2023년
                            val = f"={idx(29)}+{idx(30)}+{idx(31)}-{idx(32)}-{idx(33)}+{idx(35)}+{idx(36)}"
                    
                    # 비교대상 (1) (40행 3열) -> 24년 총액(38행, 3열) 참조
                    elif r == 40 and c == 3:
                        val = f"={idx(38, 3)}" # 40행에서 본인의 38행 3열(D41) 참조
                    
                    # 비교대상 (2) (41행 3열) -> 24년(본인열)과 23년(오른쪽열) 조합
                    elif r == 41 and c == 3:
                        # 23년 데이터는 현재열(3) 기준 오른쪽(+1) 열인 4번열(E)
                        v23 = f"({idx(29, 4)}+{idx(30, 4)}+{idx(31, 4)}-{idx(32, 4)}+{idx(33, 4)}+{idx(35, 4)}+{idx(36, 4)})"
                        v24 = f"({idx(30, 3)}+{idx(31, 3)}-{idx(32, 3)}+{idx(33, 3)}+{idx(35, 3)}+{idx(36, 3)})"
                        val = f"=({v23}*1.025)+{v24}"

                    # 인상률 (43, 44행) -> 25년 총액(38행, 2열)과 비교대상(40/41행, 3열)
                    elif r == 43:
                        val = f"=IFERROR(({idx(38, 2)}-{idx(40, 3)})/{idx(40, 3)}, 0)"
                    elif r == 44:                        val = f"=IFERROR(({idx(38, 2)}-{idx(41, 3)})/{idx(41, 3)}, 0)"

                # --- [C. 일반 값 처리] ---
                if val == "":
                    it = self.table.item(r, c)
                    if it:
                        txt = it.text().replace(',', '').strip()
                        if c < 2:
                            val = "'" + txt if txt.startswith(('-', '+', '=')) else txt
                        else:
                            val = txt if txt else "0"
                    else:
                        val = "0"
                
                row_data.append(val)
            lines.append("\t".join(row_data))
            
        QApplication.clipboard().setText("\n".join(lines))

        


    def paste_selection(self):
        text = QApplication.clipboard().text()
        curr = self.table.currentItem()
        if not text or not curr: return
        
        r_s, c_s = curr.row(), curr.column()
        self.table.blockSignals(True)
        
        changed_cols = set()
        # 15, 28번 등은 결과값이 들어갈 곳이므로 보호 리스트에 유지
        protected_rows = [0, 6, 7, 15, 28, 29, 38, 39, 40, 41, 42, 43, 44]

        lines = text.splitlines()
        for i, line in enumerate(lines):
            parts = line.split('\t')
            for j, val in enumerate(parts):
                r, c = r_s + i, c_s + j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    if c < 2: continue
                    changed_cols.add(c)
                    if r not in protected_rows:
                        item = self.table.item(r, c)
                        if item and (item.flags() & Qt.ItemIsEditable):
                            item.setText(val.strip().replace(',', ''))
        
        self.table.blockSignals(False)
        # 붙여넣기 후 모든 변경된 열에 대해 계산 강제 실행
        for col_idx in sorted(changed_cols):
            trigger = self.table.item(1, col_idx) # 임의의 행으로 트리거
            if trigger:
                self.calculate_s2(trigger)



                


                
    def keyPressEvent(self, event):
        if event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_C: self.copy_selection()
        elif event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_V: self.paste_selection()
        elif event.key() in (Qt.Key_Return, Qt.Key_Enter):
            curr_row = self.table.currentRow()
            if curr_row < self.table.rowCount() - 1:
                self.table.setCurrentCell(curr_row + 1, self.table.currentColumn())
        else: super().keyPressEvent(event)







    def contextMenuEvent(self, event):
        menu = QMenu(self)
        
        # --- [스타일 적용: 선택 시 파란 배경, 하얀 글씨] ---
        menu.setStyleSheet("""
            QMenu::item:selected {
                background-color: #0078d7; /* 파란색 하이라이트 */
                color: white;              /* 하얀색 글자 */
            }
        """)
        
        cp = menu.addAction("복사")
        ps = menu.addAction("붙여넣기")
        
        # 메뉴 실행
        action = menu.exec_(QCursor.pos())
        
        if action == cp: 
            self.copy_selection()
        elif action == ps: 
            self.paste_selection()




