from django.db import models

class TBAAAA01(models.Model):
    id = models.CharField(max_length=100, primary_key=True)
    year = models.CharField(max_length=10)
    number = models.CharField(max_length=10)
    date = models.CharField(max_length=50, blank=True, null=True)
    title = models.CharField(max_length=200, blank=True, null=True)
    receive = models.CharField(max_length=100, blank=True, null=True)
    writer = models.CharField(max_length=100, blank=True, null=True)
    binder = models.CharField(max_length=100, blank=True, null=True)
    reg_type = models.CharField(max_length=100, blank=True, null=True)
    file = models.CharField(max_length=200, blank=True, null=True)
    status = models.CharField(max_length=100, blank=True, null=True)
    company = models.CharField(max_length=100, blank=True, null=True)
    contents = models.TextField(blank=True, null=True)
    boss = models.CharField(max_length=100, blank=True, null=True)
    boss_other = models.CharField(max_length=100, blank=True, null=True)
    line = models.CharField(max_length=100, blank=True, null=True)
    post = models.CharField(max_length=50, blank=True, null=True)
    address = models.CharField(max_length=200, blank=True, null=True)
    homepage = models.CharField(max_length=200, blank=True, null=True)
    tel = models.CharField(max_length=100, blank=True, null=True)
    fax = models.CharField(max_length=100, blank=True, null=True)
    email = models.CharField(max_length=100, blank=True, null=True)
    open = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        db_table = 'TBAAAA01'




class Board(models.Model):
    title = models.CharField(max_length=200)      # 글 제목
    content = models.TextField()                  # 글 내용
    created_at = models.DateTimeField(auto_now_add=True)  # 작성 날짜

    class Meta:
        db_table = 'TBAABB01'   # 실제 DB 테이블명
        verbose_name = '게시글'
        verbose_name_plural = '게시글들'

    def __str__(self):
        return self.title










