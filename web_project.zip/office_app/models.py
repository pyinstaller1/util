from django.db import models

class TBAAAA01(models.Model):
    id = models.TextField(primary_key=True)   # Primary Key 설정
    year = models.TextField()
    number = models.TextField()
    title = models.TextField()
    contents = models.TextField()

    class Meta:
        db_table = 'TBAAAA01'   # DB 테이블명 설정
