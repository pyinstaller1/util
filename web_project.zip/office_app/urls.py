from django.urls import path
from .views import list_view, init_data

urlpatterns = [
    path('list/', list_view, name='list_view'),
    path('list/', list_data, name='list_data'),

]
