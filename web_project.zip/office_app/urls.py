from django.urls import path
from .views import list_view, list_data, get_content, detail_view

urlpatterns = [
    path('list_view/', list_view, name='list_view'),
    path('list_data/', list_data, name='list_data'),
    path('get_content/', get_content, name='get_content'),
    path('detail_view', detail_view, name='detail_view'),

]
