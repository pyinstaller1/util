import comtypes.client

# 한글 열기
hwp = comtypes.client.CreateObject("HWPFrame.HwpObject")
hwp.RegisterModule("FilePathCheckDLL", "FilePathCheckerModule")

# HWP 파일 열기 (절대경로를 권장)
file_path = r"C:\Users\Administrator\web_project\office_app\업무시스템 권한 부여 요청.hwp"
hwp.Open(file_path, "HWP", "forceopen:true")   # 세 번째 인자 추가

# 커서를 문서 끝으로 이동하고 숫자 1 추가
hwp.MovePos(3)  # 3: 문서 끝
hwp.InsertText("1")

# 저장 및 닫기
hwp.Save()
hwp.Quit()
