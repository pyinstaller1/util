from django.shortcuts import render
from django.core.paginator import Paginator
from .models import TBAAAA01
import math

def list_view(request):
    all_records = TBAAAA01.objects.all().order_by('-id')
    paginator = Paginator(all_records, 10)

    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    total_pages = paginator.num_pages
    current_page = page_obj.number

    # 현재 페이지가 속한 묶음 계산 (묶음 크기 10)
    group_size = 10
    current_group = (current_page - 1) // group_size  # 0-based index 그룹 번호

    start_page = current_group * group_size + 1
    end_page = min(start_page + group_size - 1, total_pages)

    page_range = range(start_page, end_page + 1)

    context = {
        'page_obj': page_obj,
        'page_range': page_range,
        'total_pages': total_pages,
    }
    return render(request, 'list_view.html', context)















