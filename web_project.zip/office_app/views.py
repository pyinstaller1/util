from django.shortcuts import render
from django.core.paginator import Paginator
from django.http import JsonResponse
from .models import TBAAAA01, TBAABB01
from django.db.models import Q
import math

def list_view(request):
    all_records = TBAAAA01.objects.all().order_by('-id')
    paginator = Paginator(all_records, 10)

    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    total_pages = paginator.num_pages
    current_page = page_obj.number

    # 현재 페이지가 속한 묶음 계산 (묶음 크기 10)
    group_size = 10
    current_group = (current_page - 1) // group_size  # 0-based index 그룹 번호

    start_page = current_group * group_size + 1
    end_page = min(start_page + group_size - 1, total_pages)

    page_range = range(start_page, end_page + 1)

    context = {
        'page_obj': page_obj,
        'page_range': page_range,
        'total_pages': total_pages,
    }
    return render(request, 'list_view.html', context)





def list_data(request):
    all_records = TBAAAA01.objects.all().order_by('-id')
    paginator = Paginator(all_records, 10)

    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    total_pages = paginator.num_pages
    current_page = page_obj.number

    # 현재 페이지가 속한 묶음 계산 (묶음 크기 10)
    group_size = 10
    current_group = (current_page - 1) // group_size  # 0-based index 그룹 번호

    start_page = current_group * group_size + 1
    end_page = min(start_page + group_size - 1, total_pages)

    page_range = range(start_page, end_page + 1)

    context = {
        'page_obj': page_obj,
        'page_range': page_range,
        'total_pages': total_pages,
    }
    return render(request, 'list_data.html', context)




def get_content(request):
    if request.method == "GET":
        row_id = request.GET.get('id')
        try:
            record = TBAAAA01.objects.get(id=row_id)
            return JsonResponse({
                'company': record.company,
                'title': record.title,                
                'content': record.contents,
                'boss': record.boss,
                'boss': record.boss,
                'receive': record.receive,
                'line': record.line,
                'number': record.number,
                'date': record.date,
                'post': record.post,
                'address': record.address,
                'homepage': record.homepage,
                'tel': record.tel,
                'fax': record.fax,
                'email': record.email,
                'open': record.open

                }, status=200)
        except TBAAAA01.DoesNotExist:
            return JsonResponse({'error': 'Record not found'}, status=404)






def detail_view(request):
    # URL에서 전달된 id 값을 가져옵니다.
    document_id = request.GET.get('id')

    if not document_id:
        return JsonResponse({'error': 'ID가 전달되지 않았습니다.'})

    try:
        # 전달된 ID 값에 해당하는 row를 DB에서 조회합니다.
        detail_view = TBAAAA01.objects.get(id=document_id)
        
        # 조회된 데이터를 JSON 형식으로 변환합니다.
        data = {
            'company': detail_view.company,
            'title': detail_view.title,
            'content': detail_view.contents,
            'boss': detail_view.boss,
            'receive': detail_view.receive,
            'line': detail_view.line,
            'number': detail_view.number,
            'date': detail_view.date,
            'post': detail_view.post,
            'address': detail_view.address,
            'homepage': detail_view.homepage,
            'tel': detail_view.tel,
            'fax': detail_view.fax,
            'email': detail_view.email,
            'open': detail_view.open
        }
        return JsonResponse(data)
    except TBAAAA01.DoesNotExist:
        return JsonResponse({'error': '해당 ID의 데이터가 없습니다.'})




def frame_page(request):
    return render(request, 'frame0.html')


def frame1(request):
    return render(request, 'frame1.html')

def menu(request):
    return render(request, 'menu.html')



# 글 리스트
def board_list(request):
    boards = TBAABB01.objects.all().order_by('-created_at')
    paginator = Paginator(boards, 10)

    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    total_pages = paginator.num_pages
    current_page = page_obj.number

    group_size = 10
    current_group = (current_page - 1) // group_size

    start_page = current_group * group_size + 1
    end_page = min(start_page + group_size - 1, total_pages)

    page_range = range(start_page, end_page + 1)

    context = {
        'page_obj': page_obj,
        'page_range': page_range,
        'total_pages': total_pages,
    }
    return render(request, 'board_list.html', context)

def board_detail(request, id):
    board = TBAABB01.objects.filter(id=id).first()  # 존재하면 객체, 없으면 None 반환
    return render(request, 'board_detail.html', {'board': board})




def search_aaaa01(request):
    
    '''
    query = request.GET.get('q', '').strip()  # 검색어 입력 받기
    results = TBAAAA01.objects.none()  # 기본 빈 쿼리셋

    if query:
        results = TBAAAA01.objects.filter(
            Q(title__icontains=query) | Q(contents__icontains=query)
        )

    context = {
        'query': query,
        'results': results
    }

    return render(request, 'search_results_aaaa01.html', context)
    '''



    query = request.GET.get('q', '')  # GET 요청에서 검색어 받기
    results = TBAAAA01.objects.filter(Q(title__icontains=query) | Q(contents__icontains=query))

    for row in results:
        row.highlighted_title = highlight(row.title or '', query)
        row.highlighted_contents = highlight(row.contents or '', query)

    context = {
        'query': query,
        'results': results,
    }
    return render(request, 'search_results_aaaa01.html', context)











from django.utils.html import escape, mark_safe
import re

def highlight(text, query):
    if not query:
        return escape(text)
    pattern = re.compile(re.escape(query), re.IGNORECASE)
    highlighted = pattern.sub(
        r'<span style="color:red; font-weight:bold; text-decoration: underline; font-size:16px;">\g<0></span>',
        escape(text)
    )
    return mark_safe(highlighted)









