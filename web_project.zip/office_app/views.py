from django.shortcuts import render
from django.core.paginator import Paginator
from django.http import JsonResponse
from .models import TBAAAA01
import math

def list_view(request):
    all_records = TBAAAA01.objects.all().order_by('-id')
    paginator = Paginator(all_records, 10)

    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    total_pages = paginator.num_pages
    current_page = page_obj.number

    # 현재 페이지가 속한 묶음 계산 (묶음 크기 10)
    group_size = 10
    current_group = (current_page - 1) // group_size  # 0-based index 그룹 번호

    start_page = current_group * group_size + 1
    end_page = min(start_page + group_size - 1, total_pages)

    page_range = range(start_page, end_page + 1)

    context = {
        'page_obj': page_obj,
        'page_range': page_range,
        'total_pages': total_pages,
    }
    return render(request, 'list_view.html', context)





def list_data(request):
    all_records = TBAAAA01.objects.all().order_by('-id')
    paginator = Paginator(all_records, 10)

    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    total_pages = paginator.num_pages
    current_page = page_obj.number

    # 현재 페이지가 속한 묶음 계산 (묶음 크기 10)
    group_size = 10
    current_group = (current_page - 1) // group_size  # 0-based index 그룹 번호

    start_page = current_group * group_size + 1
    end_page = min(start_page + group_size - 1, total_pages)

    page_range = range(start_page, end_page + 1)

    context = {
        'page_obj': page_obj,
        'page_range': page_range,
        'total_pages': total_pages,
    }
    return render(request, 'list_data.html', context)




def get_content(request):
    if request.method == "GET":
        row_id = request.GET.get('id')
        try:
            record = TBAAAA01.objects.get(id=row_id)
            return JsonResponse({
                'company': record.company,
                'title': record.title,                
                'content': record.contents,
                'boss': record.boss,
                'boss': record.boss,
                'receive': record.receive,
                'line': record.line,
                'number': record.number,
                'date': record.date,
                'post': record.post,
                'address': record.address,
                'homepage': record.homepage,
                'tel': record.tel,
                'fax': record.fax,
                'email': record.email,
                'open': record.open

                }, status=200)
        except TBAAAA01.DoesNotExist:
            return JsonResponse({'error': 'Record not found'}, status=404)






def detail_view(request):
    # URL에서 전달된 id 값을 가져옵니다.
    document_id = request.GET.get('id')

    if not document_id:
        return JsonResponse({'error': 'ID가 전달되지 않았습니다.'})

    try:
        # 전달된 ID 값에 해당하는 row를 DB에서 조회합니다.
        detail_view = TBAAAA01.objects.get(id=document_id)
        
        # 조회된 데이터를 JSON 형식으로 변환합니다.
        data = {
            'company': detail_view.company,
            'title': detail_view.title,
            'content': detail_view.contents,
            'boss': detail_view.boss,
            'receive': detail_view.receive,
            'line': detail_view.line,
            'number': detail_view.number,
            'date': detail_view.date,
            'post': detail_view.post,
            'address': detail_view.address,
            'homepage': detail_view.homepage,
            'tel': detail_view.tel,
            'fax': detail_view.fax,
            'email': detail_view.email,
            'open': detail_view.open
        }
        return JsonResponse(data)
    except TBAAAA01.DoesNotExist:
        return JsonResponse({'error': '해당 ID의 데이터가 없습니다.'})
