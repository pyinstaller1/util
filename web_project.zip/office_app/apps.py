from django.apps import AppConfig


class OfficeAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'office_app'
