﻿import streamlit as st
import subprocess
import re
from transformers import MarianMTModel, MarianTokenizer
import warnings

warnings.filterwarnings("ignore", category=FutureWarning)

trans_path = "./trans/ko-en"
tokenizer = MarianTokenizer.from_pretrained(trans_path)
model = MarianMTModel.from_pretrained(trans_path)

def translate(text):
    tokens = tokenizer(text, return_tensors="pt", padding=True)
    generated_ids = model.generate(**tokens)
    return tokenizer.decode(generated_ids[0], skip_special_tokens=True, clean_up_tokenization_spaces=True)

LLAMA_RUN_PATH = "D:\\model\\llama.cpp\\build\\bin\\Release\\llama-run.exe"
MODEL_PATH = "D:\\model\\llama-3.2-Korean-Bllossom-3B-gguf-Q4_K_M.gguf"

st.set_page_config(page_title="챗봇", page_icon=":robot_face:")
st.title(":red[NHIS] 챗봇 :robot_face:")

if "messages" not in st.session_state:
    st.session_state["messages"] = []

for role, msg in st.session_state["messages"]:
    st.chat_message(role).write(msg)

question = st.chat_input("질문을 입력하세요.")
if question:
    st.chat_message("user").write(question)

    translated = translate(question)
    question_trans = "Please answer between 80 and 150 tokens in Korean. " + translated

    print("번역문:", question_trans)  # 디버그 출력

    prompt = f"<s>[INST] {question_trans} [/INST]"

    ansi_escape = re.compile(r'\x1B[@-_][0-?]*[ -/]*[@-~]')

    process = subprocess.Popen(
        [LLAMA_RUN_PATH, MODEL_PATH, "-n", "256", "--temp", "0.7", "--top-p", "0.9", prompt],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding='utf-8',
        bufsize=1,
    )

    message_area = st.chat_message("assistant").empty()
    message_area.write("답변 생성중...")

    answer = ""
    first_token_received = False

    for line in process.stdout:
        line = ansi_escape.sub('', line).strip()
        if "Loading model" in line:
            continue
        if not line:
            continue

        if not first_token_received:
            message_area.empty()
            first_token_received = True

        answer += line + "\n"

        clean_answer = answer.replace("[INST]", "").replace("[/INST]", "").replace("보건보험", "건강보험").strip()
        message_area.write(clean_answer)

    process.stdout.close()
    process.wait()

    st.session_state["messages"].append(("user", question))
    st.session_state["messages"].append(("assistant", clean_answer))
