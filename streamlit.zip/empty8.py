﻿from langchain_openai import ChatOpenAI
import os
import streamlit as st
import subprocess


LLAMA_RUN_PATH = "D:\\model\\llama.cpp\\build\\bin\\Release\\llama-run.exe"
MODEL_PATH = "D:\\model\\llama-3.2-Korean-Bllossom-3B-gguf-Q4_K_M.gguf"


st.set_page_config(page_title="챗봇", page_icon=":robot_face:")
st.title(":red[NHIS]&nbsp;_챗봇_  &nbsp;&nbsp;&nbsp; :robot_face:")



if "messages" not in st.session_state:
    st.session_state["messages"] = []

if "messages" in st.session_state and len(st.session_state["messages"]) > 0:
    for chat_message in st.session_state["messages"]:
        st.chat_message(chat_message[0]).write(chat_message[1])

question = st.chat_input("질문을 입력하세요.")
if question:
    st.chat_message("user").write(question)


    
    # key = os.getenv('OPENAI_KEY')
    # llm = ChatOpenAI(openai_api_key = key)
    # answer = llm.invoke(question)
    # answer = answer.content

    # answer = "LLM 모델이 연결되지 않았습니다."




    try:
        # subprocess로 실시간 출력 받기
        process = subprocess.Popen(
            [LLAMA_RUN_PATH, MODEL_PATH, "-n", "256", "--temp", "0.7", "--top-p", "0.9", prompt],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1
        )

        answer_box = st.chat_message("assistant")
        placeholder = answer_box.empty()
        output = ""

        for line in process.stdout:
            output += line
            placeholder.markdown("```\n" + output.strip() + "\n```")  # 실시간 갱신

        process.wait()

        st.session_state["messages"].append(("assistant", output.strip()))

    except FileNotFoundError:
        error_msg = "❌ llama-run 실행 파일을 찾을 수 없습니다."
        st.chat_message("assistant").write(error_msg)
        st.session_state["messages"].append(("assistant", error_msg))

    except Exception as e:
        error_msg = f"❌ 오류 발생: {str(e)}"
        st.chat_message("assistant").write(error_msg)
        st.session_state["messages"].append(("assistant", error_msg))














    
    # st.chat_message("assistant").write(answer)
    

    st.session_state["messages"].append(["user", question])
    # st.session_state["messages"].append(["assistant", answer])

