﻿import streamlit as st



from transformers import MarianMTModel, MarianTokenizer
import warnings

warnings.filterwarnings("ignore", category=FutureWarning)

trans_path = "./trans/ko-en"


tokenizer = MarianTokenizer.from_pretrained(trans_path)
model = MarianMTModel.from_pretrained(trans_path)

def translate(text):
    tokens = tokenizer(text, return_tensors="pt", padding=True)
    generated_ids = model.generate(**tokens)
    return tokenizer.decode(generated_ids[0], skip_special_tokens=True, clean_up_tokenization_spaces=True)




st.set_page_config(page_title="챗봇", page_icon=":robot_face:")
st.title(":red[NHIS]&nbsp;_English_ _번역봇_  &nbsp;&nbsp;&nbsp; :robot_face:")

if "messages" not in st.session_state:
    st.session_state["messages"] = []

if "messages" in st.session_state and len(st.session_state["messages"]) > 0:
    for chat_message in st.session_state["messages"]:
        st.chat_message(chat_message[0]).write(chat_message[1])

question = st.chat_input("질문을 입력하세요.")
if question:
    st.chat_message("user").write(question)
    answer = translate(question)
    st.chat_message("assistant").write(answer)

    st.session_state["messages"].append(["user", question])
    st.session_state["messages"].append(["assistant", answer])

