﻿import streamlit as st

from transformers import M2M100ForConditionalGeneration, M2M100Tokenizer

import warnings
warnings.filterwarnings("ignore", category=FutureWarning)





def translate_ko_ja(text):

    model_path = "./trans/facebook_m2m100"
    tokenizer = M2M100Tokenizer.from_pretrained(model_path)
    model = M2M100ForConditionalGeneration.from_pretrained(model_path)
    
    tokenizer.src_lang = "ko"
    encoded = tokenizer(text, return_tensors="pt")
    generated = model.generate(**encoded, forced_bos_token_id=tokenizer.get_lang_id("ja"))
    return tokenizer.batch_decode(generated, skip_special_tokens=True)[0]




st.set_page_config(page_title="챗봇", page_icon=":robot_face:")
st.title(":red[NHIS]&nbsp;_일본어_ _번역봇_ &nbsp; 🔴")

if "messages" not in st.session_state:
    st.session_state["messages"] = []

if "messages" in st.session_state and len(st.session_state["messages"]) > 0:
    for chat_message in st.session_state["messages"]:
        st.chat_message(chat_message[0]).write(chat_message[1])

question = st.chat_input("질문을 입력하세요.")
if question:
    st.chat_message("user").write(question)
    answer = translate_ko_ja(question)
    st.chat_message("assistant").write(answer)

    st.session_state["messages"].append(["user", question])
    st.session_state["messages"].append(["assistant", answer])

