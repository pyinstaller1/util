from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QKeySequence

rank_count = 8

# [2] 실시간 우측 정렬 델리게이트 (s7용 통합 버전)
class S7RightAlignedDelegate(QStyledItemDelegate):
    def __init__(self, parent):
        super().__init__(parent)
        # 생성 시 부모(TableWidget)에 이벤트 필터 설치 (평소 상태 감시용)
        if parent:
            parent.installEventFilter(self)
            
    def createEditor(self, parent, option, index):
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        # 입력 중(에디터 활성화)일 때 키 감시용 필터 설치
        editor.installEventFilter(self)
        return editor

    def eventFilter(self, obj, event):
        if event.type() == event.KeyPress:
            # 1. 엔터 키: 아래 셀로 이동 (단순 선택)
            if event.key() in [Qt.Key_Return, Qt.Key_Enter]:
                table = self.parent()
                curr = table.currentIndex()
                next_row = curr.row() + 1
                if next_row < table.rowCount():
                    # 데이터를 저장하기 위해 currentIndex 변경
                    next_idx = table.model().index(next_row, curr.column())
                    table.setCurrentIndex(next_idx)
                return True

            # 2. 오른쪽 방향키
            elif event.key() == Qt.Key_Right:
                # 입력창이 아니거나, 커서가 끝일 때 이동
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == len(obj.text()):
                    self.move_focus(forward=True)
                    return True

            # 3. 왼쪽 방향키
            elif event.key() == Qt.Key_Left:
                # 입력창이 아니거나, 커서가 시작일 때 이동
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == 0:
                    self.move_focus(forward=False)
                    return True

        return super().eventFilter(obj, event)

    def move_focus(self, forward=True):
        """좌우 이동 시 인덱스만 변경 (자동 편집 X)"""
        table = self.parent()
        curr_idx = table.currentIndex()
        next_col = curr_idx.column() + 1 if forward else curr_idx.column() - 1
        
        if 0 <= next_col < table.columnCount():
            next_idx = table.model().index(curr_idx.row(), next_col)
            table.setCurrentIndex(next_idx)

    def setModelData(self, editor, model, index):
        # 콤마 제거 후 숫자 데이터 저장
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)




class S7ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if val is None or str(val).strip() == "":
                return "0.00"

            try:
                clean_val = str(val).replace(',', '')
                num = float(clean_val)

                # 모든 숫자를 소수 2자리로 표시
                return format(num, ",.2f")

            except:
                return val

        return super().data(role)


class Sheet7Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_sky_blue = QColor(220, 235, 245) 
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        title = QLabel("다. 증원소요인건비 대상 인원")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)
        
        self.table = QTableWidget(18, 15)
        
        months = [f"{i}월" for i in range(1, 13)]
        headers = ["구분", "직급"] + months + ["평균인원"]
        self.table.setHorizontalHeaderLabels(headers)

        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)

        self.table.verticalHeader().setDefaultSectionSize(26)
        self.table.verticalHeader().setFixedWidth(25)
        
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section {
                background-color: #f4f4f4; padding: 2px;
                border: 0px; border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: bold;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; border: 0px; 
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: normal;  /* 행 번호 글자 굵게 하지 않음 */
            }            
            QScrollBar:vertical { background: #f1f1f1; width: 16px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:vertical { background: #888888; min-height: 30px; border-radius: 2px; }
            QScrollBar:horizontal { background: #f1f1f1; height: 16px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:horizontal { background: #888888; min-width: 30px; border-radius: 2px; }
            QScrollBar::add-line, QScrollBar::sub-line { width: 0px; height: 0px; }
        """)

        self.table.verticalHeader().setDefaultAlignment(Qt.AlignCenter)


        self.delegate = S7RightAlignedDelegate(self.table)
        for i in range(2, 15): 
            self.table.setItemDelegateForColumn(i, self.delegate)

        self.setup_content()
        
        self.table.setColumnWidth(0, 50); self.table.setColumnWidth(1, 60)
        for i in range(2, 14): self.table.setColumnWidth(i, 70)
        self.table.setColumnWidth(14, 70)

        self.table.itemChanged.connect(self.calculate_s7)
        layout.addWidget(self.table)

    def setup_content(self):
        self.table.blockSignals(True)
        # 전역변수 rank_count 사용 (예: 9)
        # 직급 리스트 동적 생성 (마지막은 항상 '계')
        ranks = ["1급", "2급", "3급", "4급", "5급", "6급", "연구직", "계"]
        full_headers = ["구분", "직급"] + [f"{i}월" for i in range(1, 13)] + ["평균인원"]
        
        # 행 위치 변수 자동 계산 (가장 중요!)
        this_year_start = 0
        this_year_end = rank_count - 1      # 8행 (당년도 계)
        
        separator1 = rank_count            # 9행 (구분선)
        mid_header = rank_count + 1        # 10행 (중간 제목)
        
        last_year_start = rank_count + 2   # 11행 (전년도 시작)
        last_year_end = (2 * rank_count) + 1 # 19행 (전년도 계)
        
        separator2 = (2 * rank_count) + 2  # 20행 (구분선)
        comment_row = (2 * rank_count) + 3 # 21행 (주석)

        self.table.setRowCount(comment_row + 1)

        for r in range(self.table.rowCount()):
            for c in range(15):
                # 1. 구분선 처리
                if r == separator1 or r == separator2:
                    item = QTableWidgetItem("")
                    item.setFlags(Qt.NoItemFlags); item.setBackground(Qt.white)
                
                # 2. 중간 제목줄 처리
                elif r == mid_header:
                    item = QTableWidgetItem(full_headers[c])
                    item.setTextAlignment(Qt.AlignCenter)
                    item.setBackground(QColor(244, 244, 244))
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    f = item.font(); f.setBold(True); item.setFont(f)
                
                # 3. 주석 처리
                elif r == comment_row:
                    comment_text = " * 당년도 증원소요인건비 대상 인원은 (3-2)직급별평균인원계산의 당년도 현원에서 (3-3)나. 근속승진의 인원을 차감한 인원임."
                    item = QTableWidgetItem(comment_text if c == 0 else "")
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                
                # 4. 데이터 영역 처리
                else:
                    item = S7ThousandSeparatorItem("0")
                    item.setTextAlignment(Qt.AlignCenter if c < 2 else Qt.AlignRight | Qt.AlignVCenter)

                    # --- [당년도 영역 설정] ---
                    if this_year_start <= r <= this_year_end:
                        # 0열 구분 (당년도)
                        if c == 0:
                            if r == this_year_start: item.setText("당년도")
                            item.setBackground(QColor(245, 245, 245))
                            item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        # 1열 직급
                        elif c == 1:
                            item.setText(ranks[r - this_year_start])
                            item.setBackground(self.base_sky_blue)
                            item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        # 데이터 입력 제한 (노란색)
                        elif 2 <= c <= 13 and r < this_year_end:
                            item.setBackground(QColor(255, 255, 225))
                            item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        # 합계 및 평균인원 (하늘색)
                        if r == this_year_end or c == 14:
                            item.setBackground(self.base_sky_blue)
                            item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                            f = item.font(); f.setBold(True); item.setFont(f)

                    # --- [전년도 영역 설정] ---
                    elif last_year_start <= r <= last_year_end:
                        # 0열 구분 (전년도)
                        if c == 0:
                            if r == last_year_start: item.setText("전년도")
                            item.setBackground(QColor(245, 245, 245))
                            item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        # 1열 직급
                        elif c == 1:
                            item.setText(ranks[r - last_year_start])
                            item.setBackground(self.base_sky_blue)
                            item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        # 합계 및 평균인원 (하늘색)
                        if r == last_year_end or c == 14:
                            item.setBackground(self.base_sky_blue)
                            item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                            f = item.font(); f.setBold(True); item.setFont(f)

                self.table.setItem(r, c, item)

        # 병합 및 높이 조정 (동적 변수 사용)
        self.table.setSpan(comment_row, 0, 1, 15)
        self.table.setSpan(this_year_start, 0, rank_count, 1) # 당년도 구분 병합
        self.table.setSpan(last_year_start, 0, rank_count, 1) # 전년도 구분 병합
        self.table.setRowHeight(separator1, 10)
        self.table.setRowHeight(separator2, 10)
        self.table.setRowHeight(comment_row, 50)
        self.table.blockSignals(False)


        
    def calculate_s7(self, item):
        if item is None: return
        row, col = item.row(), item.column()
        
        # 1. 특수 행 위치 계산 (기존과 동일)
        sep1 = rank_count
        mid_header = rank_count + 1
        sep2 = (2 * rank_count) + 2
        comment_row = (2 * rank_count) + 3

        # [필수 체크] 입력/수정 시 계산에서 제외할 영역 (가로/세로 합계가 들어가는 14열 포함)
        if col < 2 or row in [sep1, mid_header, sep2, comment_row]: 
            return 
        
        self.table.blockSignals(True)
        try:
            # 2. 당년도/전년도 영역 판단
            if 0 <= row < rank_count:
                data_rows = list(range(0, rank_count - 1))
                sum_row = rank_count - 1
            elif (rank_count + 2) <= row < (2 * rank_count + 2):
                last_start = rank_count + 2
                data_rows = list(range(last_start, last_start + rank_count - 1))
                sum_row = last_start + rank_count - 1
            else:
                return

            # [내부 헬퍼 함수] 숫자가 아닌 문자열(코드 등)이 오면 0으로 치환
            def get_safe_val(r, c):
                it = self.table.item(r, c)
                if not it: return 0.0
                txt = it.text().replace(',', '').strip()
                try:
                    return float(txt) if txt else 0.0
                except ValueError:
                    return 0.0 # 숫자가 아니면 0 처리

            # 3. [가로 계산] 해당 행 평균 (14열)
            row_sum = sum(get_safe_val(row, c) for c in range(2, 14))
            avg_val = round(row_sum / 12, 2)
            
            target_14 = self.table.item(row, 14)
            if target_14: target_14.setData(Qt.EditRole, avg_val)

            # 4. [세로 계산] 해당 열 합계 (sum_row)
            if col < 14:
                col_sum = sum(get_safe_val(r, col) for r in data_rows)
                sum_cell = self.table.item(sum_row, col)
                if sum_cell: sum_cell.setData(Qt.EditRole, int(col_sum))

            # 5. [교차 계산] 합계 행의 평균인원 업데이트
            total_avg = sum(get_safe_val(r, 14) for r in data_rows)
            final_sum_cell = self.table.item(sum_row, 14)
            if final_sum_cell: final_sum_cell.setData(Qt.EditRole, round(total_avg, 2))
            
        except Exception as e:
            # 예상치 못한 에러만 출력
            print(f"S7 Calc Critical Error: {e}")
        finally: 
            self.table.blockSignals(False)

            


    def sync_s7_data(self, s4_data, s6_data):
        """S7 = S4(현원) - S6(근속승진) 데이터를 계산하여 반영"""
        self.table.blockSignals(True)
        try:
            num_rows = min(len(s4_data), len(s6_data))
            for r in range(num_rows):
                for m in range(12):
                    result_val = s4_data[r][m] - s6_data[r][m]
                    # 당년도가 위(0~7행)로 왔으므로 target_row를 0+r로 변경
                    target_row = 0 + r
                    target_col = 2 + m
                    it = self.table.item(target_row, target_col)
                    if it:
                        it.setData(Qt.EditRole, result_val)
                # 가로 평균 계산 트리거
                self.calculate_s7(self.table.item(r, 2))
        finally:
            self.table.blockSignals(False)

    def get_average_personnel_to3(self):
        """S3 연동을 위한 데이터 추출 (에러 방지 및 rank_count 대응)"""
        data = []
        
        # rank_count = 9일 때:
        # 당년도 데이터 행: 0 ~ 8행 (9개)
        # 중간 구분선/제목 등 제외하고
        # 전년도 데이터 시작 행: rank_count + 2 (즉, 11행부터 시작)
        
        prev_start_row = rank_count + 2
        
        for i in range(rank_count):
            # 1. 당년도 데이터 추출 (0 ~ 8행)
            c_it = self.table.item(i, 14)
            c_val = 0.0
            if c_it:
                txt = c_it.text().replace(',', '').strip()
                try:
                    c_val = float(txt) if txt else 0.0
                except ValueError:
                    c_val = 0.0

            # 2. 전년도 데이터 추출 (11 ~ 19행)
            p_it = self.table.item(i + prev_start_row, 14)
            p_val = 0.0
            if p_it:
                txt = p_it.text().replace(',', '').strip()
                try:
                    p_val = float(txt) if txt else 0.0
                except ValueError:
                    p_val = 0.0
            
            data.append((p_val, c_val))
            
        return data








    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        
        min_r, max_r = min(r.topRow() for r in selection), max(r.bottomRow() for r in selection)
        min_c, max_c = min(r.leftColumn() for r in selection), max(r.rightColumn() for r in selection)
        
        # rank_count = 9 기준 위치 정보
        data_rows_in_table = rank_count - 1  # 8줄
        this_year_sum_row = rank_count - 1   # 8행 (당년도 계)
        last_year_sum_row = (2 * rank_count) + 1 # 19행 (전년도 계)
        
        # 특수 행 (구분선, 제목, 주석)
        specials = [rank_count, rank_count + 1, (2 * rank_count) + 2, (2 * rank_count) + 3]

        lines = []
        for r in range(min_r, max_r + 1):
            if r in specials:
                row_data = []
                for c in range(min_c, max_c + 1):
                    it = self.table.item(r, c)
                    row_data.append(it.text().replace('\n', ' ') if it else "")
                lines.append("\t".join(row_data))
                continue

            row_data = []
            for c in range(min_c, max_c + 1):
                # 1. 가로 평균 (14열)
                if c == 14 and r not in [this_year_sum_row, last_year_sum_row]:
                    # 현재 행(ROW)의 왼쪽 12개 셀(COLUMN-12 ~ COLUMN-1) 평균
                    formula = (
                        "=ROUND(AVERAGE("
                        "INDEX($1:$1048576,ROW(),COLUMN()-12):"
                        "INDEX($1:$1048576,ROW(),COLUMN()-1)"
                        "),2)"
                    )
                    row_data.append(formula)

                # 2. 세로 합계 ('계' 행)
                elif (r == this_year_sum_row or r == last_year_sum_row) and 2 <= c <= 14:
                    # 현재 위치에서 위로 data_rows_in_table(8칸) 떨어진 곳부터 바로 위까지
                    # INDEX($1:$1048576, ROW()-8, COLUMN()) : ROW()-1 방식
                    offset = data_rows_in_table
                    formula = (
                        f"=SUM("
                        f"INDEX($1:$1048576,ROW()-{offset},COLUMN()):"
                        f"INDEX($1:$1048576,ROW()-1,COLUMN())"
                        f")"
                    )
                    row_data.append(formula)

                # 3. 일반 데이터 (숫자)
                else:
                    it = self.table.item(r, c)
                    if it:
                        val = it.text().replace(',', '').strip()
                        row_data.append(val)
                    else:
                        row_data.append("")
            
            lines.append("\t".join(row_data))
        
        QApplication.clipboard().setText("\n".join(lines))
        

    def paste_selection(self):
        text = QApplication.clipboard().text()
        curr = self.table.currentItem()
        if not text or not curr: return
        
        r_s, c_s = curr.row(), curr.column()
        self.table.blockSignals(True)
        
        # --- [추가] 차단해야 할 특수 행 계산 ---
        sep1 = rank_count                # 9행 (구분선)
        mid_h = rank_count + 1           # 10행 (2번째 표 제목줄)
        sep2 = (2 * rank_count) + 2      # 20행 (구분선)
        comm = (2 * rank_count) + 3      # 21행 (주석)
        protected_rows = [sep1, mid_h, sep2, comm]
        # ------------------------------------

        affected_rows = set() 
        
        try:
            for i, line in enumerate(text.splitlines()):
                if not line.strip(): continue
                for j, val in enumerate(line.split('\t')):
                    r, c = r_s + i, c_s + j
                    
                    if r < self.table.rowCount() and c < self.table.columnCount():
                        item = self.table.item(r, c)
                        if item:
                            # [핵심 수정] 
                            # 1. 계산식 열(14열), 구분열(0,1열) 차단
                            # 2. 보호된 행(제목줄, 구분선, 주석) 차단
                            # 3. 노란색(계산된 영역) 및 하늘색(계) 배경색 차단
                            bg_color = item.background().color()
                            is_protected_bg = (bg_color == QColor(255, 255, 225) or 
                                               bg_color == self.base_sky_blue or
                                               bg_color == QColor(245, 245, 245)) # 0열 색상
                            
                            if c < 2 or c == 14 or r in protected_rows or is_protected_bg:
                                continue 
                            
                            # 데이터 입력
                            item.setText(val.strip().replace(',', ''))
                            affected_rows.add(r)
        finally:
            self.table.blockSignals(False)

        if not affected_rows:
            return

        # 이후 계산 로직 동일...
        for row_idx in affected_rows:
            it = self.table.item(row_idx, 2)
            if it: self.calculate_s7(it)

        # 세로 합계 계산 (데이터가 들어간 표의 합계행을 찾아 계산)
        sample_row = list(affected_rows)[0]
        target_sum_row = (rank_count - 1) if sample_row < rank_count else ((rank_count + 2) + rank_count - 1)

        for col in range(2, 14): # 14열(평균인원) 제외하고 2~13열 합계 계산
            it = self.table.item(target_sum_row, col)
            if it: self.calculate_s7(it)

        # S3 연동 신호
        first_row = min(affected_rows)
        trigger_item = self.table.item(first_row, 14) 
        if trigger_item:
            self.table.itemChanged.emit(trigger_item)



                

    def show_context_menu(self, pos):
        menu = QMenu(); cp = menu.addAction("복사 (Ctrl+C)"); ps = menu.addAction("붙여넣기 (Ctrl+V)")
        act = menu.exec_(self.table.viewport().mapToGlobal(pos))
        if act == cp: self.copy_selection()
        elif act == ps: self.paste_selection()

        

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Copy): self.copy_selection()
        elif event.matches(QKeySequence.Paste): self.paste_selection()
        else: super().keyPressEvent(event)
